package model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Mod�le servant de support pour les r�servations de salle
 */
public class Reservation {
	
	private int idReservation;
	private Room room;
	private User user;
	private String hourStart;
	private String hourEnd;
	private String date;
	
	/**
	 * Instancier une nouvelle r�servation sans Id
	 * 
	 * @param room Room associ�e � la r�servation
	 * @param user User poss�dant la r�servation
	 * @param hourEnd Heure de fin de la r�servation
	 */
	public Reservation(Room room, User user, String hourStart, String hourEnd, String date) {
		this.room = room;
		this.user = user;
		this.hourStart = hourStart;
		this.hourEnd = hourEnd;
		this.date = date;
	}
	
	/**
	 * Instancier une nouvelle r�servation
	 * 
	 * @param idReservation Num�ro unique de la r�servation
	 * @param room Room associ�e � la r�servation
	 * @param user User poss�dant la r�servation
	 * @param hourEnd Heure de fin de la r�servation
	 */
	public Reservation(int idReservation, Room room, User user, String hourStart, String hourEnd, String date) {
		this.idReservation = idReservation;
		this.room = room;
		this.user = user;
		this.hourStart = hourStart;
		this.hourEnd = hourEnd;
		this.date = date;
	}
	
	/**
	 * Instancier une nouvelle r�servation pour un user non authentifi�
	 * 
	 * @param idReservation Num�ro unique de la r�servation
	 * @param room Room associ�e � la r�servation
	 * @param hourEnd Heure de fin de la r�servation
	 */
	public Reservation(int idReservation, Room room, String hourStart, String hourEnd, String date) {
		this(idReservation, room, null, hourStart, hourEnd, date);
	}
	

	/**
	 * R�cup�rer l'id de la r�servation
	 * 
	 * @return l'id de la r�servation
	 */
	public int getIdReservation() {
		return idReservation;
	}
	
	/**
	 * R�cup�rer la room associ�e � la r�servation
	 * 
	 * @return la room associ�e � la r�servation
	 */
	public Room getRoom() {
		return room;
	}
	
	/**
	 * R�cup�rer l'user de la r�servation
	 * 
	 * @return l'user de la r�servation, ou null s'il n'y en a pas encore
	 */
	public User getUser() {
		return user;
	}
	
	/**
	 * R�cup�rer l'heure de d�but de la r�servation
	 * 
	 * @return L'heure de d�but de la r�servation
	 */
	public String getHourStart() {
		return hourStart;
	}
	
	/**
	 * R�cup�rer l'heure de fin de la r�servation
	 * 
	 * @return L'heure de fin de la r�servation
	 */
	public String getHourEnd() {
		return hourEnd;
	}
	
	/**
	 * R�cup�rer la date de la r�servation au format Fr
	 * 
	 * @return la date de la r�servation
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * R�cup�rer la date de la r�servation au format Fr
	 * 
	 * @return la date de la r�servation
	 */
	public String getDateFr() {
		return convertDate2(date);
	}	
	
	/**
	 * R�cup�rer la date de la r�servation au format Eng
	 * 
	 * @return la date de la r�servation
	 */
	public String getDateEng() {
		return convertDate(date);
	}
	
	/**
	 * Renvoie l'heure actuelle
	 * 
	 * @return l'heure actuelle
	 */
	public static String now() {
		SimpleDateFormat d = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		return d.format(date);
	}
	
	/**
	 * Renvoie la date actuelle
	 * 
	 * @return la date actuelle
	 */
	public static String today() {
		SimpleDateFormat d = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		return d.format(date);
	}
	
	/**
	 * Convertit une date au format Fr en format Ang
	 * 
	 * @param String date a convertir
	 * @return la date Ang
	 */
	public static String convertDate(String date) {
		String englishDate = date.substring(6, 10) + "/" + date.substring(3, 5) + "/" + date.substring(0, 2);
		return englishDate;
	}
	
	/**
	 * Convertit une date au format Ang en format Fr
	 * 
	 * @param String date a convertir
	 * @return la date Fr
	 */
	public static String convertDate2(String date) {
		  String frenchDate = date.substring(8, 10) + "/" + date.substring(5, 7) + "/" + date.substring(0, 4);
		  return frenchDate;
	}

}