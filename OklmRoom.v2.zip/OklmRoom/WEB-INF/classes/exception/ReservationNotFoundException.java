package exception;


/**
 * En cas de reservation introuvable
 */
public class ReservationNotFoundException extends NotFoundException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
