package exception;

/**
 * Dans le cas ou un comtpe existe d�j� (login d�j� utilis�)
 */
public class UserAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
