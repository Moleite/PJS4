package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import exception.IntrouvableException;
import model.Reservation;
import model.Room;
import model.Dispatcher;
import model.User;


public class ReservationController extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private Dispatcher tas = Dispatcher.getInstance();

	/**
	 * Renvoie � l'action correspondante aux param�tres
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException { 
        String action = request.getParameter("action");
		action = (action == null) ? "index" : action;
		
		if(action.equals("lister"))
			this.listerAction(request, response);
		else if(action.equals("commande"))
			this.commandeAction(request, response);
		else if(action.equals("annuler"))
			this.annulerAction(request, response);
		else
			request.getRequestDispatcher("/views/erreur/404.jsp").forward(request, response);

	}
	
	/**
	 * Liste les vols en fonction des param�tres du formulaire
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void listerAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String villeDestination = request.getParameter("VilleDestination");
		String dateDepart = request.getParameter("DateDebut");
		String nbPlaces = request.getParameter("NbPlaces");
		
		ArrayList<Room> vols  = (ArrayList<Room>) tas.getVols(villeDestination, dateDepart, Integer.parseInt(nbPlaces));
		request.setAttribute("vols", vols);

		HttpSession session = request.getSession();
		session.setAttribute("nbPlaces", nbPlaces);

		request.getRequestDispatcher("/views/reservation/vols.jsp").forward(request, response);
	}
	
	/**
	 * Permet de commander une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	public void commandeAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String choix = (request.getParameter("choix") == null) ? "0" : request.getParameter("choix");
		int numeroVol = Integer.parseInt(choix);

		if(!this.estConnecte(request)) {
			request.getSession().setAttribute("commande", numeroVol);
			response.sendRedirect("login");
			return;
		}
		
		User compte = (User) request.getSession().getAttribute("user");

		String nbPlacesAttribut = (String) request.getSession().getAttribute("nbPlaces");
		int nbPlaces = Integer.parseInt(nbPlacesAttribut);

		try {
			Room vol = tas.getVol(numeroVol);
			tas.ajouterReservation(vol, compte, nbPlaces);
		} catch (IntrouvableException e) {
			e.printStackTrace();
			request.setAttribute("erreur", "Le vol pour lequel vous souhaitez r�server n'a pas �t� trouv� !");
			request.getRequestDispatcher("/views/erreur/500.jsp").forward(request, response);
			return;
		}
		request.getSession().removeAttribute("commande");
		response.sendRedirect("compte?action=reservations");
	}
	
	/**
	 * Permet d'annuler une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException  
	 */
	private void annulerAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		if(!this.estConnecte(request)) {
			response.sendRedirect("login");
			return;
		}
		
		String id = (request.getParameter("id") == null) ? "0" : request.getParameter("id");
		int numeroReservation = Integer.parseInt(id);;
		
		try {
			Reservation reservation = tas.getReservation(numeroReservation);

			tas.removeReservation(reservation);

		} catch (IntrouvableException e) {
			e.printStackTrace();
			request.setAttribute("erreur", "La r�servation que vous souhaitez annuler n'a pas �t� trouv� !");
			request.getRequestDispatcher("/views/erreur/500.jsp").forward(request, response);
			return;
		}
		
		response.sendRedirect("compte?action=reservations");
		return;
	}
	
	/**
	 * V�rifie si l'utilisateur est connect�
	 * 
	 * @return true si il est connect�
	 */
	private boolean estConnecte(HttpServletRequest request) {
		return(request.getSession().getAttribute("user") != null);
	}
}
