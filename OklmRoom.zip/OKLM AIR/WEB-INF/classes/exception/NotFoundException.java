package exception;

/**
 * Est retournée si une entrée requise en base de données n'a pas été trouvée
 */
public abstract class NotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}