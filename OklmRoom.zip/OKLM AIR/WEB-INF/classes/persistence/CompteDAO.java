package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;
import model.CompteExisteDejaException;
import model.CompteIntrouvableException;

/**
 * DataAccessObject en charge de g�rer la r�cup�ration des comptes
 */
public class CompteDAO {
	
	private Connection connection;
	private static CompteDAO instance = new CompteDAO();
	
	/**
	 * Cr�er un nouvel accesseur de comptes
	 */
	private CompteDAO() {
		try {
			this.connection = DB_TAS.getConnection();
		} catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Obtenir l'instance de CompteDAO (Singleton)
	 * 
	 * @return l'instance de CompteDAO
	 */
	public static CompteDAO getInstance() {
		return instance;
	}
	
	
	public void ajouterCompte(User compte) throws CompteExisteDejaException {
		try {
			String requete = "INSERT INTO COMPTES VALUES (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, compte.getPseudo());
			preparedStatement.setString(2, compte.getPassword());
			preparedStatement.setString(3, compte.getLastName());
			preparedStatement.setString(4, compte.getFirstName());
			preparedStatement.setString(5, compte.getRight());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CompteExisteDejaException();
		}
	}
	
	public User trouverCompte(String log, String pass) throws CompteIntrouvableException {
		try {
			User compte = null;
			String requete = "SELECT * FROM COMPTES WHERE login = ? AND mdp = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, log);
			preparedStatement.setString(2, pass);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				String login = resultats.getString("Login");
				String mdp = resultats.getString("Mdp");
				String nom = resultats.getString("Nom");
				String prenom = resultats.getString("Prenom");
				String role = resultats.getString("Role");
				compte = new User(login, mdp, nom, prenom, role);
			}
			
			if(compte != null)
				return compte;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new CompteIntrouvableException();
	}
	
	public User trouverCompte(String login) throws CompteIntrouvableException {
		try {
			User compte = null;
			String requete = "SELECT * FROM COMPTES WHERE login = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, login);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				String mdp = resultats.getString("Mdp");
				String nom = resultats.getString("Nom");
				String prenom = resultats.getString("Prenom");
				String role = resultats.getString("Role");
				compte = new User(login,mdp,nom,prenom,role);
			}
			
			if(compte != null)
				return compte;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new CompteIntrouvableException();
	}
}
