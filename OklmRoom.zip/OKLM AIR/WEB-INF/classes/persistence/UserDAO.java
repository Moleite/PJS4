package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;
import model.UserAlreadyExistException;
import model.UserNotFoundException;

/**
 * DataAccessObject en charge de g�rer la r�cup�ration des comptes
 */
public class UserDAO {
	
	private Connection connection;
	private static UserDAO instance = new UserDAO();
	
	/**
	 * Cr�er un nouvel accesseur de comptes
	 */
	private UserDAO() {
		try {
			this.connection = DB_TAS.getConnection();
		} catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Obtenir l'instance de CompteDAO (Singleton)
	 * 
	 * @return l'instance de CompteDAO
	 */
	public static UserDAO getInstance() {
		return instance;
	}
	
	
	public void ajouterCompte(User user) throws UserAlreadyExistException {
		try {
			String requete = "INSERT INTO USER VALUES (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, user.getPseudo());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getLastName());
			preparedStatement.setString(4, user.getFirstName());
			preparedStatement.setString(5, user.getRight());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserAlreadyExistException();
		}
	}
	
	public User trouverCompte(String log, String pass) throws UserNotFoundException {
		try {
			User compte = null;
			String requete = "SELECT * FROM COMPTES WHERE login = ? AND mdp = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, log);
			preparedStatement.setString(2, pass);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				String login = resultats.getString("Login");
				String mdp = resultats.getString("Mdp");
				String nom = resultats.getString("Nom");
				String prenom = resultats.getString("Prenom");
				String role = resultats.getString("Role");
				compte = new User(login, mdp, nom, prenom, role);
			}
			
			if(compte != null)
				return compte;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new CompteIntrouvableException();
	}
	
	public User trouverCompte(String login) throws CompteIntrouvableException {
		try {
			User compte = null;
			String requete = "SELECT * FROM COMPTES WHERE login = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setString(1, login);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				String mdp = resultats.getString("Mdp");
				String nom = resultats.getString("Nom");
				String prenom = resultats.getString("Prenom");
				String role = resultats.getString("Role");
				compte = new User(login,mdp,nom,prenom,role);
			}
			
			if(compte != null)
				return compte;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new CompteIntrouvableException();
	}
}
