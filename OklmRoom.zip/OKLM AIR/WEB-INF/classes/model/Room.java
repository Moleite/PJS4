package model;

/**
 * Mod�le servant de support pour les salles
 */
public class Room {
	
	private int idRoom;
	private int nbRoom;
	private int floor;
	private boolean reserved;
	private int nbSeat;
	private int nbSeatLeft;
	private float screen;
	private String processor;
	private int ram;
	
	
	
	/**
	 * Instancier une nouvelle salle
	 * 
	 * @param id l'id de la salle
	 * @param num numero de la salle
	 * @param floor etage de la salle
	 * @param screen taille des ecrans de la salle
	 * @param nbSeat nombre de places de la salle
	 * @param processor processeur des ordinateurs de la salle
	 * @param ram ram des ordinateurs de la salle
	 */	
	public Room(int id, int num, int floor, float screen, int nbSeat, String processor, int ram ) {
		this.idRoom = id;
		this.nbRoom = num;
		this.reserved = false;
		this.nbSeat = nbSeat;
		this.floor = floor;
		this.screen = screen;	
		this.processor = processor;
		this.ram = ram;
	}

	/**
	 * R�cup�rer le num�ro unique de la salle
	 * 
	 * @return le num�ro de la salle
	 */
	public int getNbRoom() {
		return nbRoom;
	}
	
	/**
	 * Savoir si la salle est deja r�serv�e ou pas
	 * 
	 * @return true si oui ou false sinon
	 */
	public boolean isReserved() {
		return reserved;
	}
	
	/**
	 * R�cup�rer le nombre de places de la salle
	 * 
	 * @return le nombre de places de la salle
	 */
	public int getNbSeat() {
		return nbSeat;
	}
	
	/**
	 * R�cup�rer l'etage de la salle
	 * 
	 * @return l'etage de la salle
	 */
	public int getEtage() {
		return floor;
	}
	
	/**
	 * R�cup�rer la taille des ecrans de la salle
	 * 
	 * @return la taille des ecrans de la salle
	 */
	public Float getScreen() {
		return screen;
	}
	
	/**
	 * R�cup�rer le processeur des ordinateurs de la salle
	 * 
	 * @return le processeur des ordinateurs de la salle
	 */
	public String getProcessor() {
		return processor;
	}

	/**
	 * R�cup�rer l'id de la salle
	 * 
	 * @return l'id de la salle
	 */
	public int getIdRoom() {
		return idRoom;
	}

	/**
	 * R�cup�rer la ram des ordinateurs de la salle
	 * 
	 * @return la ram des ordinateurs de la salle
	 */
	public int getRam() {
		return ram;
	}

	
	
}
