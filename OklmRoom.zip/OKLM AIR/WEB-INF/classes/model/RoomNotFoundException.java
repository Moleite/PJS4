package model;

/**
 * En cas de salle introuvable
 */
public class RoomNotFoundException extends NotFoundException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
