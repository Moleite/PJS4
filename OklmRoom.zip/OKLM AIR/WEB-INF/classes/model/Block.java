package model;

/**
 * Mod�le support des batiments
 */
public class Block {
	private int idBlock;
	private String name;
	
	
	/**
	 * Instancier un nouveau batiment
	 * 
	 * @param id id du batiment
	 * @param name nom du batiment
	 */
	public Block(int id, String name){
		this.idBlock = id;
		this.name = name;
	}
	
	
	/**
	 * R�cup�rer l'id du batiment
	 * 
	 * @return l'id du batiment
	 */
	public int getIdBlock() {
		return idBlock;
	}
		
	/**
	 * R�cup�rer le nom du batiment
	 * 
	 * @return le nom du batiment
	 */
	public String getName() {
		return name;
	}
	
	
	
		
	
}
