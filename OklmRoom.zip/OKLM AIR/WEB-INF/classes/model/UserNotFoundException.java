package exception;

/**
 * Dans le cas o� le compte n'as pas �t� trouv�
 */
public class UserNotFoundException extends NotFoundException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
