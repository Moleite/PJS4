package model;

/**
 * Mod�le support des �tages
 */
public class Floor {
	
	private int idFloor;
	private Block block;
	
	
	/**
	 * Instancier un nouvel �tage
	 * 
	 * @param id id de l'�tage
	 * @param block le batiment de l'�tage
	 */
	public Floor(int id, Block block){
		this.idFloor = id;		
	}

	
	/**
	 * R�cup�rer le batiment
	 * 
	 * @return le batiment
	 */
	public Block getBlock() {
		return block;
	}


	/**
	 * R�cup�rer l'id de l'�tage
	 * 
	 * @return l'id de l'�tage
	 */
	public int getIdFloor() {
		return idFloor;
	}
	
	


	

}
