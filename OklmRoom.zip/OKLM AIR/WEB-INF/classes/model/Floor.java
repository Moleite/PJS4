package model;

/**
 * Mod�le support des etages
 */
public class Floor {
	
	private int idFloor;
	private Block block;
	
	
	/**
	 * Instancier un nouvel etage
	 * 
	 * @param id id de l'�tage
	 * @param block le batiment de l'etage
	 */
	public Floor(int id, Block block){
		this.idFloor = id;		
	}

	
	/**
	 * R�cup�rer le batiment
	 * 
	 * @return le batiment
	 */
	public Block getBlock() {
		return block;
	}


	/**
	 * R�cup�rer l'id de l'etage
	 * 
	 * @return l'id de l'etage
	 */
	public int getIdFloor() {
		return idFloor;
	}
	
	


	

}
