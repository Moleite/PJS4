package model;

/**
 * Mod�le support des utilisateurs
 */
public class User {
	
	private int idUser;
	private String pseudo;
	private String password;
	private String lastName;
	private String firstName;
	private String right; 
	private int reservations;
	
	/**
	 * Instancier un nouvel utilisateur
	 * 
	 * @param pseudo Login de l'utilisateur
	 * @param psw Mot de passe de l'utilisateur
	 * @param lastName Nom de l'utilisateur
	 * @param firstName Prenom de l'utilisateur
	 * @param right le role de l'utilisateur (eleve, professeur, Admin)
	 */
	public User(String pseudo, String psw, String lastName, String firstName, String right) {
		this.pseudo = pseudo;
		this.password = psw;
		this.lastName = lastName;
		this.firstName = firstName;
		this.right = right;
		this.reservations = 0;
	}
	
	/**
	 * R�cup�rer le pseudo de l'utilisateur
	 * 
	 * @return le pseudo de l'utilisateur
	 */
	public String getPseudo() {
		return pseudo;
	}

	/**
	 * R�cup�rer le mot de passe de l'utilisateur
	 * 
	 * @return le mot de passe de l'utilisateur
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * R�cup�rer le nom de l'utilisateur
	 * 
	 * @return le nom de l'utilisateur
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * R�cup�rer le prenom de l'utilisateur
	 * 
	 * @return le prenom de l'utilisateur
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * R�cup�rer le role de l'utilisateur
	 * 
	 * @return le role de l'utilisateur
	 */
	public String getRight() {
		return right;
	}
	
	
	@Override
	public String toString() {
		return this.lastName + " (" + this.pseudo + ")";
	}
	
	/**
	 * R�cup�rer l'id de l'utilisateur
	 * 
	 * @return l'id de l'utilisateur
	 */
	public int getIdUser() {
		return idUser;
	}
	
	/**
	 * R�cup�rer le nombre de reservation de l'utilisateur
	 * 
	 * @return  le nombre de reservation de l'utilisateur
	 */
	public int getReservations() {
		return reservations;
	}

}
