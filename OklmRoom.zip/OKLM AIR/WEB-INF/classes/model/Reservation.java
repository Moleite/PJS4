package model;

import java.util.Date;

/**
 * Mod�le servant de support pour les r�servations de salle
 */
public class Reservation {
	
	private int idReservation;
	private Room room;
	private User user;
	private int slot;
	private Date date;
	

	/**
	 * Instancier une nouvelle r�servation
	 * 
	 * @param idReserv Num�ro unique de la r�servation
	 * @param room salle associ� � la r�servation
	 * @param user utilisateur poss�dant la r�servation
	 */
	public Reservation(int idReserv, Room room, User user, int slot) {
		this.idReservation = idReserv;
		this.room = room;
		this.user = user;
		this.slot = slot;
		
		
	}
	
	/**
	 * Instancier une nouvelle r�servation pour un utilisateur non authentifi�
	 * 
	 * @param numResev Num�ro unique de la r�servation
	 * @param room salle associ� � la r�servation
	 * @param slot le creneau de la reservation
	 */
	public Reservation(int numResev, Room room, int slot ) {
		this(numResev, room, null, slot );
	}
	

	/**
	 * R�cup�rer l'id de la r�servation
	 * 
	 * @return l'id de la r�servation
	 */
	public int getIdReservation() {
		return idReservation;
	}
	
	/**
	 * R�cup�rer la salle associ�e � la r�servation
	 * 
	 * @return la salle associ�e � la r�servation
	 */
	public Room getRoom() {
		return room;
	}
	
	/**
	 * R�cup�rer l'utilisateur de la r�servation
	 * 
	 * @return l'utilisateur de la r�servation, ou null s'il n'y en a pas encore
	 */
	public User getUser() {
		return user;
	}
	

	/**
	 * R�cup�rer le creneau de la reservation
	 * 
	 * @return l'utilisateur de la r�servation
	 */
	public int getSlot() {
		return slot;
	}

	public void setSlot(int slot) {
		this.slot = slot;
	}
}