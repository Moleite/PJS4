package exception;

/**
 * Est retourn�e si une entr�e requise en base de donn�es n'a pas �t� trouv�e
 */
public abstract class NotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}