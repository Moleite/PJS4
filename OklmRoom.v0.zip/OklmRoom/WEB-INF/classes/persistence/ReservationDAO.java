package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exception.NotFoundException;
import exception.ReservationNotFoundException;
import model.Reservation;
import model.Room;
import model.User;

/**
 * DataAccessObject en charge de g�rer la r�cup�ration et l'enregistrement des r�servations
 */
public class ReservationDAO {
	
	private Connection connection;
	private static ReservationDAO instance = new ReservationDAO();
	private RoomDAO roomDAO = RoomDAO.getInstance();
	private UserDAO userDAO = UserDAO.getInstance();

	/**
	 * Cr�er un nouvel accesseur de reservation, utilise un verrou pour synchroniser son compteur
	 */
	private ReservationDAO() {
		try {
			this.connection = DataBase.getConnection();
		} catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Obtenir l'instance de ReservationDAO (Singleton)
	 * 
	 * @return l'instance de ReservationDAO
	 */
	public static ReservationDAO getInstance() {
	      return instance;
	}
/**
	 * Ajouter une r�servation � un utiilisateur
	 * 
	 * @param room la salle associ� � la r�servation
	 * @param user le compte qui poss�dera la r�servation 
	 * @param slot le cr�neau de la r�servation
	 */
	public void addReservation(Room room, User user, String date, String hourStart, String hourEnd) {
		int idUser = 0, idRoom = 0;
		
		try {
			String request1 = "SELECT * FROM USERS WHERE pseudo = ?";
			PreparedStatement preparedStatement1 = this.connection.prepareStatement(request1);
			preparedStatement1.setString(1, user.getPseudo());
			ResultSet resultats1 = preparedStatement1.executeQuery();
			
			while (resultats1.next()){
				idUser = resultats1.getInt("idUser");
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		try {
			String request2 = "SELECT * FROM ROOMS WHERE idRoom = ?";
			PreparedStatement preparedStatement2 = this.connection.prepareStatement(request2);
			preparedStatement2.setInt(1, room.getIdRoom());
			ResultSet resultats2 = preparedStatement2.executeQuery();
				
			while (resultats2.next()){
				idRoom = resultats2.getInt("idRoom");
			}
			
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		
		try {
			String request3 = "INSERT INTO RESERVATIONS (UserId, RoomId, Start, End, Date) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement3 = this.connection.prepareStatement(request3);
			preparedStatement3.setInt(1, idUser);
			preparedStatement3.setInt(2, idRoom);
			preparedStatement3.setString(3, hourStart);
			preparedStatement3.setString(4, hourEnd);
			preparedStatement3.setString(5, date);

			preparedStatement3.executeUpdate();
			
		}
		catch (SQLException e3) {
			e3.printStackTrace();
		}
	}
	
	/**
	 * Retrouver une r�servation � partir de son num�ro 
	 * 
	 * @param idReservation Le num�ro de la r�servation
	 * @return la r�servation correspondante
	 * @throws NotFoundException si la r�servation ou un de ses composants n'existe pas
	 */
	public Reservation findReservation(int idReservation) throws NotFoundException {
		try {
			Reservation reservation = null;
			String request = "SELECT * FROM RESERVATIONS WHERE idReservation = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(request);
			preparedStatement.setInt(1, idReservation);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()){
				Room room = this.roomDAO.findRoom(resultats.getInt("RoomId"));
				User user = this.userDAO.findUser(resultats.getInt("user"));
				reservation = new Reservation(idReservation, room, user, resultats.getString("start"), resultats.getString("end"));
			}
			
			if(reservation != null)
				return reservation;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new ReservationNotFoundException();
	}
	
	/**
	 * R�cup�rer les r�servations d'un utilisateur
	 * 
	 * @param user le compte dont on souhaite obtenir les r�servations
	 * @return la liste des r�servations du compte
	 */
	public List<Reservation> findReservations(User user) {
		List<Reservation> reservations = new ArrayList<Reservation>();
		
		try {
			String request = "SELECT * FROM RESERVATIONS WHERE UserId = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(request);
			preparedStatement.setInt(1, user.getIdUser());
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()){
				try {
					Room room = roomDAO.findRoom(resultats.getInt("roomId"));
					Reservation reservation = new Reservation(resultats.getInt("idReservation"), room, user, resultats.getString("start"), resultats.getString("end"));
					reservations.add(reservation);
					
				} catch (NotFoundException e) {
					e.printStackTrace();
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return reservations;
	}

	/**
	 * Supprimer une r�servation
	 * 
	 * @param reservation La r�servation � supprimer
	 */
	public void cancelReservation(Reservation reservation) {
		try {
			String resquest3 = "DELETE FROM RESERVATIONS WHERE idReservation = ? ";
			PreparedStatement preparedStatement3 = this.connection.prepareStatement(resquest3);
			preparedStatement3.setInt(1, reservation.getIdReservation());
			preparedStatement3.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
}
