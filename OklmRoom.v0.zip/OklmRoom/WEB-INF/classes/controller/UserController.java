package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import model.Reservation;
import model.Dispatcher;
import model.User;
import exception.UserAlreadyExistException;


public class UserController extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private Dispatcher dispatcher = Dispatcher.getInstance();
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException { 
        
		String on = "";
		if (request.getParameterMap().containsKey("on")) {
			on = request.getParameter("on");
		}
		
		String action = request.getParameter("action");
		action = (action == null) ? "index" : action;

		if(action.equals("dashboard"))
			this.dashboardAction(request, response);
		else if(action.equals("signUp"))
			this.signUpAction(request, response, on);
		else if(action.equals("listReservations"))
			this.listReservationsAction(request, response, on);
		else if(action.equals("signOut"))
			this.signOutAction(request, response);
		else if(action.equals("promoteUser"))
			this.promoteUserAction(request, response);
		else
			request.getRequestDispatcher("/views/error/404.jsp").forward(request, response);
	}

	/**
	 * Afficher la page d'accueil de l'espace user
	 * 
	 * @param request requ�te HTTP courante
	 * @param response r�ponse HTTP pour la requ�te courante
	 * @throws IOException
	 * @throws ServletException
	 */
	private void dashboardAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		if(!this.isConnected(request)) {
			response.sendRedirect("login");
			return;
		}
		request.getRequestDispatcher("/views/user/dashboard.jsp").forward(request, response);
	}

	/**
	 * Inscrire un nouvel user
	 * 
	 * @param request requ�te HTTP courante
	 * @param response r�ponse HTTP pour la requ�te courante
	 * @throws IOException
	 * @throws ServletException
	 */
	private void signUpAction(HttpServletRequest request, HttpServletResponse response, String on) throws IOException, ServletException {
		
		if(on.equals("app")) {
			//deserialize l'object JSON
//			String lastname = "?";
//			String firstname = "?";
//			String pseudo = "?";
//			String password = "?";
//			
//			try {
//				dispatcher.addUser(lastname, firstname, pseudo, password);
//				response.setHeader("statut", "ok");
//			} catch (UserAlreadyExistException e) {
//				e.printStackTrace();
//				response.setHeader("statut", "ko");
//			}
		} else {
			String lastname = request.getParameter("lastName");
			String firstname = request.getParameter("firstName");
			String pseudo = request.getParameter("pseudo");
			String password = request.getParameter("password");
			
			if("POST".equals(request.getMethod())) {
				try {
					HttpSession session = request.getSession();
					session.setAttribute("user", dispatcher.addUser(lastname, firstname, pseudo, password));		
					if(session.getAttribute("reservationAttribute") != null) {
						response.sendRedirect("reservation?action=reserve&choice=" + session.getAttribute("reservationAttribut"));
						return;
					}
					response.sendRedirect("index");
					return;
				}
				catch (UserAlreadyExistException e) {
					e.printStackTrace();
					request.setAttribute("error", true);
				}
			}
			
			request.getRequestDispatcher("/views/user/signUp.jsp").forward(request, response);
		}
	}
	
	/**
	 * R�cup�rer les reservation de l'user en session
	 * 
	 * @param request requ�te HTTP courante
	 * @param response r�ponse HTTP pour la requ�te courante
	 * @throws IOException
	 * @throws ServletException
	 */
	private void listReservationsAction(HttpServletRequest request, HttpServletResponse response, String on) throws IOException, ServletException {
		if(on.equals("app")) {
			//deserialize l'object JSON
//			User user = (User) "?";
//			ArrayList<Reservation> reservations = (ArrayList<Reservation>) this.dispatcher.getReservations(user);
//			serialise le tableau de reservations en JSON et le renvoie
//			response.setHeader("statut", "ok");

		}else {
			if(!this.isConnected(request)) {
				response.sendRedirect("login");
				return;
			}
			
			User user = (User) request.getSession().getAttribute("user");
			ArrayList<Reservation> reservations = (ArrayList<Reservation>) this.dispatcher.getReservations(user);
			
			request.setAttribute("reservations", reservations);
			request.getRequestDispatcher("/views/user/listReservations.jsp").forward(request, response);
		}
	}

	/**
	 * D�connecter l'user en session
	 * 
	 * @param request requ�te HTTP courante
	 * @param response r�ponse HTTP pour la requ�te courante
	 * @throws IOException
	 * @throws ServletException
	 */
	private void signOutAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.getSession().removeAttribute("user");
		response.sendRedirect("index");
	}
	
	/**
	 * Promote un User
	 * 
	 * @param request requ�te HTTP courante
	 * @param response r�ponse HTTP pour la requ�te courante
	 * @throws IOException
	 * @throws ServletException
	 */
	private void promoteUserAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String pseudo = request.getParameter("Pseudo");
			
		if("POST".equals(request.getMethod())) {		
			if(pseudo != null) {
				response.sendRedirect("user?action=promoteUser");
				return;
			}
			response.sendRedirect("index");
			return;
		}
		
		request.getRequestDispatcher("/views/user/promoteUser.jsp").forward(request, response);
	}
	
	/**
	 * V�rifie si un user est actuellement connect�
	 * 
	 * @param request requ�te HTTP courante
	 * @return true si l'utilisateur est connect�, false sinon
	 */
	private boolean isConnected(HttpServletRequest request) {
		return(request.getSession().getAttribute("user") != null);
	}
}