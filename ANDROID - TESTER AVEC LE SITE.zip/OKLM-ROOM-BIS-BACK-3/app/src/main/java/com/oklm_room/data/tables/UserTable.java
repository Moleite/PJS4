package com.oklm_room.data.tables;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class UserTable {
    public static final String USERS_TABLE_NAME = "USERS";
    //Id
    public static final String USERS_ID = "iduser";
    //Nom
    public static final String USERS_NOM = "lastname";
    //Prénom
    public static final String USERS_PRENOM = "firstname";
    //Identifiant
    public static final String USERS_PSEUDO = "pseudo";
    //Mot de passe
    public static final String USERS_PASSWORD = "password";
    //Droit
    public static final String USERS_RIGHT = "right";
    //Nb réservs
    public static final String USERS_RESERVATIONS = "reservations";

    //Requête pour créer la table users
    public static final String USERS_TABLE_CREATE = "CREATE TABLE " + USERS_TABLE_NAME + " (" +
            USERS_ID + " INTEGER AUTO_INCREMENT PRIMARY KEY, " +
            USERS_NOM + " TEXT NOT NULL, " +
            USERS_PRENOM + " TEXT NOT NULL, " +
            USERS_PSEUDO + " TEXT UNIQUE NOT NULL, " +
            USERS_PASSWORD + " TEXT NOT NULL, " +
            USERS_RIGHT + " TEXT NOT NULL, "+
            USERS_RESERVATIONS+ " INTEGER NOT NULL); ";


    public static final String USERS_TABLE_DROP = "DROP TABLE IF EXISTS " + USERS_TABLE_NAME + ";";
}
