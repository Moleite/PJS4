package com.oklm_room.http_requests;


import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by hadbi on 25/03/2016.
 */
public class HttpReservation {
    ArrayList<NameValuePair> ListeParametre = new ArrayList<NameValuePair>();
    HttpPost httppost = new HttpPost(/*ULR DU SITE*/);

    public void Reservation(String Salle) throws Error {

        try {
            ListeParametre.add(new BasicNameValuePair("NomSalle", Salle));

            httppost.setEntity(new UrlEncodedFormEntity(ListeParametre));
            HttpClient httpClient = new DefaultHttpClient();
            httpClient.execute(httppost);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

