package com.oklm_room.data.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.oklm_room.data.manager.DBManager;
import com.oklm_room.data.model.User;
import com.oklm_room.data.tables.UserTable;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class UserManager {
    DBManager dbm;
    SQLiteDatabase db;

    public UserManager(Context ctx){
        dbm= new DBManager(ctx, "pjs4", null, 1);
    }

    public void open(){
        db=dbm.getWritableDatabase();
    }

    public void close(){
        db.close();
    }

    //UTILISATEUR
    //Methode ajouter Table User
    // @Override
    public long addUser(String nom, String prenom, String ident, String mdp, String right, String reservation) {

        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_NOM, nom);
        value.put(UserTable.USERS_PRENOM, prenom);
        value.put(UserTable.USERS_PSEUDO, ident);
        value.put(UserTable.USERS_PASSWORD, mdp);
        value.put(UserTable.USERS_RIGHT, right);
        value.put(UserTable.USERS_RESERVATIONS, reservation);
        return db.insert(UserTable.USERS_TABLE_NAME, null, value);
    }

    public long addUser(User u) {

        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_NOM, u.getLast_name());
        value.put(UserTable.USERS_PRENOM, u.getFirst_name());
        value.put(UserTable.USERS_PSEUDO, u.getPseudo());
        value.put(UserTable.USERS_PASSWORD, u.getPassword());
        value.put(UserTable.USERS_RIGHT, u.getRight());
        value.put(UserTable.USERS_RESERVATIONS, u.getReservations());
        return db.insert(UserTable.USERS_TABLE_NAME, null, value);
    }

    //Methode supprimer un utilisateur en fonction de son identifiant
    //  @Override
    public void deleteUser(String pseudo) {
        db.delete(UserTable.USERS_TABLE_NAME, UserTable.USERS_PSEUDO + " = " + pseudo, null);
    }

    //Vérifie que l'utilisateur existe à partir de sont ident et MDP
    //Si fonctionne pas c'est parce que rawQuery fait apparemment que la premiere
    //ligne donc faire une simple boucle pour prendre toutes les lignes
//    @Override
    public boolean exists(String pseudo, String MDP){
        Cursor c = db.rawQuery("SELECT * FROM " + UserTable.USERS_TABLE_NAME +" WHERE " + UserTable.USERS_PSEUDO + "= ? AND " + UserTable.USERS_PASSWORD + "= ?", new String[]{pseudo,MDP});
        System.out.println("Etat cursor ident + mdp : " + c);
        if(c.getCount()>0)
            return true;
        else
            return false;
    }

    // @Override
    public boolean existsPseudo(String pseudo){
        Cursor c = db.rawQuery("SELECT * FROM " + UserTable.USERS_TABLE_NAME +" WHERE " + UserTable.USERS_PSEUDO + "= ?", new String[]{pseudo});
        System.out.println("Etat cursor ident : " + c);
        if(c.getCount()>0)
            return true;
        else
            return false;
    }

    //Renvoie toutes les infos d'un user dans un array (nom...)
    //Si fonctionne pas, revoir les arguments de getString
    //Sinon la boucle
    //Sinon la requête
    //   @Override
    public Map<String, String> getUser(String pseudo) {
        Map<String, String> list = new HashMap<String, String>();
        Cursor c = db.rawQuery("SELECT * FROM " + UserTable.USERS_TABLE_NAME + " WHERE " + UserTable.USERS_PSEUDO + "= ?", new String[]{pseudo});
        if (c.moveToFirst()) {
            do {
                list.put(UserTable.USERS_NOM, c.getString(2));
                list.put(UserTable.USERS_PRENOM, c.getString(3));
                list.put(UserTable.USERS_PSEUDO, c.getString(4));
                list.put(UserTable.USERS_PASSWORD, c.getString(5));
                list.put(UserTable.USERS_RIGHT, c.getString(6));
                list.put(UserTable.USERS_RESERVATIONS, c.getString(7));

            } while (c.moveToNext());
        }
        return list;
    }

    public User getUser(String pseudo, String mdp){
        //Cursor c = db.rawQuery("SELECT * FROM " + UserTable.USERS_TABLE_NAME +" WHERE " + UserTable.USERS_PSEUDO + "= ? AND " + UserTable.USERS_PASSWORD + "= ?", new String[]{pseudo,mdp});

        SQLiteDatabase bdd = dbm.getReadableDatabase();

        Cursor c = bdd.rawQuery("SELECT * FROM " + UserTable.USERS_TABLE_NAME + " WHERE " + UserTable.USERS_PSEUDO + "= ? AND " + UserTable.USERS_PASSWORD + "= ?", new String[]{pseudo, mdp});

        //c.moveToFirst();

        User u = new User();
        u.setFirst_name(c.getString(3));
        u.setPseudo(c.getString(4));
        u.setPassword(c.getString(5));

        return u;
    }

    //Modifier le nom d'un utilisateur
    //  @Override
    public int modifyUserNom (String pseudo, String nom) {
        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_NOM, nom);
        return db.update(UserTable.USERS_TABLE_NAME, value, UserTable.USERS_PSEUDO + "=" + pseudo,null);
    }

    //Modifier le prenom d'un utilisateur
    // @Override
    public int modifyUserPrenom (String pseudo, String prenom) {
        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_PRENOM, prenom);
        return db.update(UserTable.USERS_TABLE_NAME, value, UserTable.USERS_PSEUDO + "=" + pseudo,null);
    }

    //Modifier le ident d'un utilisateur
    //  @Override
    public int modifyUserIdent (String pseudo, String newPseudo) {
        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_PSEUDO, newPseudo);
        return db.update(UserTable.USERS_TABLE_NAME, value, UserTable.USERS_PSEUDO + "=" + pseudo,null);
    }


    //Modifier le MDP d'un utilisateur
    //  @Override
    public int modifyUserMdp (String pseudo, String mdp) {
        ContentValues value = new ContentValues();
        value.put(UserTable.USERS_PASSWORD, mdp);
        return db.update(UserTable.USERS_TABLE_NAME, value, UserTable.USERS_PSEUDO + "=" + pseudo,null);
    }


}
