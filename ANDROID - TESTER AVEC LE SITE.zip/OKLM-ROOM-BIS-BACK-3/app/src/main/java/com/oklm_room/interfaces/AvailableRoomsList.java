package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.oklm_room.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AvailableRoomsList extends Activity {

    private ListView avail;
    final String EXTRA_RES = "res";
    final String EXTRA_H_BEGIN = "beg";
    final String EXTRA_H_END = "end";
    final String EXTRA_DATE = "date";
    final String EXTRA_RAM = "ram";
    final String EXTRA_SCREEN = "screen";
    final String EXTRA_PROCESSOR = "processor";
    final String EXTRA_USE = "useRoom";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_available_rooms_list);

        avail = (ListView) findViewById(R.id.ListAvail);

        List<String> list = new ArrayList<String>();


        String tab[][] = {
                {"1", "12", "11", "Libre Service"},
                {"1", "2", "28", "Non réservée"},
                {"0", "13", "28", "Non réservée"},
                {"0", "3", "4", "Libre Service"},
        };

        String[] infos = {"Etage", "Numéro de salle", "Nombre de places", "Disponibilité"};


        list.add(infos[0] + ": " + tab[0][0] + " \n" + infos[1] + ": " + tab[0][1] + " \n" + infos[2] + ": " + tab[0][2] + " \n" + infos[3] + ": " + tab[0][3]);
        list.add(infos[0] + ": " + tab[1][0] + " \n" + infos[1] + ": " + tab[1][1] + " \n" + infos[2] + ": " + tab[1][2] + " \n" + infos[3] + ": " + tab[1][3]);
        list.add(infos[0] + ": " + tab[2][0] + " \n" + infos[1] + ": " + tab[2][1] + " \n" + infos[2] + ": " + tab[2][2] + " \n" + infos[3] + ": " + tab[2][3]);
        list.add(infos[0] + ": " + tab[3][0] + " \n" + infos[1] + ": " + tab[3][1] + " \n" + infos[2] + ": " + tab[3][2] + " \n" + infos[3] + ": " + tab[3][3]);




       /* list.add("1"+"12"+ "11"+ "Libre Service");
        list.add("1"+"12"+ "11"+ "Libre Service");*/
       /* list.add(tab[1]);
        list.add(tab[2]);
        list.add(tab[3]);*/

        ArrayAdapter<String> dataAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        avail.setAdapter(dataAdapter);
        Intent intent = getIntent();
        //On récupère les données dont on a besoin pour la confirmation
        final String h_begin = intent.getStringExtra(EXTRA_H_BEGIN);
        final String h_end = intent.getStringExtra(EXTRA_H_END);
        final String date = intent.getStringExtra(EXTRA_DATE);
        final String use= intent.getStringExtra(EXTRA_USE);
        final String ram= intent.getStringExtra(EXTRA_RAM);
        final String processor= intent.getStringExtra(EXTRA_PROCESSOR);
        final String screen= intent.getStringExtra(EXTRA_SCREEN);




        avail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent conf = new Intent(AvailableRoomsList.this, ConfirmReservation.class);
                String itemRes = ((TextView)view).getText().toString();
                Toast toast = Toast.makeText(AvailableRoomsList.this,  itemRes, Toast.LENGTH_LONG);
                toast.show();

                conf.putExtra(EXTRA_RES, itemRes);
                conf.putExtra(EXTRA_H_BEGIN, h_begin);
                conf.putExtra(EXTRA_H_END, h_end);
                conf.putExtra(EXTRA_DATE, date);
                conf.putExtra(EXTRA_PROCESSOR, processor);
                conf.putExtra(EXTRA_SCREEN, screen);
                conf.putExtra(EXTRA_RAM, ram);
                conf.putExtra(EXTRA_USE, use);
                startActivity(conf);
            }
        });

    }
}
