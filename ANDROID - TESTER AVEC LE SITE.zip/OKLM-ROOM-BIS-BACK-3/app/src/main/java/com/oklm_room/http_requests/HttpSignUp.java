package com.oklm_room.http_requests;

import android.util.Log;

import com.oklm_room.errors.ErrorSignUp;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by tatlot1 on 25/03/2016.
 */
public class HttpSignUp {

    ArrayList<NameValuePair> ListeParametre = new ArrayList<NameValuePair>();
    HttpPost httppost = new HttpPost(/*ULR DU SITE*/);

    public void inscription(final String nom, final String prenom, final String pseudo, final String mdp) throws ErrorSignUp {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    HttpClient httpClient = new DefaultHttpClient();

                    JSONObject jsonobj = new JSONObject();

                    try {
                        jsonobj.put("Nom", nom);
                        jsonobj.put("Prenom", prenom);
                        jsonobj.put("Pseudo", pseudo);
                        jsonobj.put("Mdp", mdp);
                        jsonobj.put("on", "app");// Momo qui a demandé
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    StringEntity se = new StringEntity(jsonobj.toString());

                    se.setContentType("application/json;charset=UTF-8");
                    se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=UTF-8"));

                    httppost.setEntity(se);

                    HttpResponse httpresponse = httpClient.execute(httppost);

                    String responseText = null;

                   /* try {
                        responseText = entityUtils.toString(httpresponse.getEntity());
                    } catch (ParseException e) {
                        e.printStackTrace();
                        Log.i("Parse Exception", e + "");
                    }




                    ListeParametre.add(new BasicNameValuePair("Nom", nom));
                    ListeParametre.add(new BasicNameValuePair("Prenom", prenom));
                    ListeParametre.add(new BasicNameValuePair("Pseudo", pseudo));
                    ListeParametre.add(new BasicNameValuePair("Mdp", mdp));

                    httppost.setEntity(new UrlEncodedFormEntity(ListeParametre));

                    httpClient.execute(httppost);*/
                } catch (IOException e) {
                    e.printStackTrace();
                }



            };
        }).start();
    }

}