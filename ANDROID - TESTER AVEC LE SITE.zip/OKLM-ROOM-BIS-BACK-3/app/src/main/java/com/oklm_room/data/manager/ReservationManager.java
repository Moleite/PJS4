package com.oklm_room.data.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.oklm_room.data.tables.ReservationTable;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class ReservationManager {
    DBManager dbm;
    SQLiteDatabase db;

    public ReservationManager(Context ctx){
        dbm= new DBManager(ctx, "pjs4", null, 1);
    }

    public void open(){
        db=dbm.getWritableDatabase();
    }

    public void close(){
        db.close();
    }


    //Methode ajouter Table Reservations
    // @Override
    public long addReservation(int user_id, int room_id, String start, String end, Date day) {

        ContentValues value = new ContentValues();
        value.put(ReservationTable.RESERVATIONS_USERS_ID, user_id);
        value.put(ReservationTable.RESERVATIONS_ROOMS_ID, room_id);
        value.put(ReservationTable.RESERVATIONS_START, start);
        value.put(ReservationTable.RESERVATIONS_END, end);
        value.put(ReservationTable.RESERVATIONS_DAY, day.toString());
        return db.insert(ReservationTable.RESERVATIONS_TABLE_NAME, null, value);
    }


    public Map<String, String> getReservationDay(String day) {
        Map<String, String> list = new HashMap<String, String>();
        Cursor c = db.rawQuery("SELECT * FROM " + ReservationTable.RESERVATIONS_TABLE_NAME + " WHERE " + ReservationTable.RESERVATIONS_DAY + "= ?", new String[]{day});
        if (c.moveToFirst()) {
            do {
                list.put(ReservationTable.RESERVATIONS_USERS_ID, c.getString(2));
                list.put(ReservationTable.RESERVATIONS_ROOMS_ID, c.getString(3));
                list.put(ReservationTable.RESERVATIONS_START, c.getString(4));
                list.put(ReservationTable.RESERVATIONS_END, c.getString(5));
                list.put(ReservationTable.RESERVATIONS_DAY, c.getString(6));

            } while (c.moveToNext());
        }
        return list;
    }

    public Map<String, String> getReservationRoom(String id_room) {
        Map<String, String> list = new HashMap<String, String>();
        Cursor c = db.rawQuery("SELECT * FROM " + ReservationTable.RESERVATIONS_TABLE_NAME + " WHERE " + ReservationTable.RESERVATIONS_ROOMS_ID + "= ?", new String[]{id_room});
        if (c.moveToFirst()) {
            do {
                list.put(ReservationTable.RESERVATIONS_USERS_ID, c.getString(2));
                list.put(ReservationTable.RESERVATIONS_ROOMS_ID, c.getString(3));
                list.put(ReservationTable.RESERVATIONS_START, c.getString(4));
                list.put(ReservationTable.RESERVATIONS_END, c.getString(5));
                list.put(ReservationTable.RESERVATIONS_DAY, c.getString(6));

            } while (c.moveToNext());
        }
        return list;
    }
}
