package com.oklm_room.data.manager;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.oklm_room.data.tables.*;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class DBManager extends SQLiteOpenHelper {

    public DBManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public DBManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(UserTable.USERS_TABLE_CREATE);
        db.execSQL(RoomTable.ROOMS_TABLE_CREATE);
        db.execSQL(ReservationTable.RESERVATIONS_TABLE_CREATE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(UserTable.USERS_TABLE_DROP);
        db.execSQL(RoomTable.ROOMS_TABLE_DROP);
        db.execSQL(ReservationTable.RESERVATIONS_TABLE_DROP);

        onCreate(db);
    }
}
