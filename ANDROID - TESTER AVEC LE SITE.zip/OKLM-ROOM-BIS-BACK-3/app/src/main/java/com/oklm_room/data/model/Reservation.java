package com.oklm_room.data.model;

import java.sql.Date;
import java.sql.Time;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class Reservation {

    private int id_reservation;
    private String user_id;
    private String room_id;
    private Time start;
    private Time end;
    private Date date;

    public Reservation(int id_reservation, String user_id, String room_id, Time start, Time end, Date date) {
        this.id_reservation = id_reservation;
        this.user_id = user_id;
        this.room_id = room_id;
        this.start = start;
        this.end = end;
        this.date = date;
    }

    public int getId_reservation() {
        return id_reservation;
    }

    public void setId_reservation(int id_reservation) {
        this.id_reservation = id_reservation;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getRoom_id() {
        return room_id;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public Time getStart() {
        return start;
    }

    public void setStart(Time start) {
        this.start = start;
    }

    public Time getEnd() {
        return end;
    }

    public void setEnd(Time end) {
        this.end = end;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
