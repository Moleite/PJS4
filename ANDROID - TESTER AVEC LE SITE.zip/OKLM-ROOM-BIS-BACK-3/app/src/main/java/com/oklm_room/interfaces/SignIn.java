package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.oklm_room.MainActivity;
import com.oklm_room.R;
import com.oklm_room.data.manager.UserManager;
import com.oklm_room.data.model.User;

public class SignIn extends Activity {

    private Button retour;
    private Button connexion;
    EditText pseudo;
    EditText mdp;

    Boolean b = new Boolean(true);
    String ps = new String();
    UserManager um;
    User u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        retour = (Button) findViewById(R.id.Retour);
        connexion = (Button) findViewById(R.id.Connexion);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);

        um = new UserManager(this);

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(SignIn.this, MainActivity.class);
                startActivity(retour);
            }
        });

        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View V) {

             //   um.open();
                u= new User();
                u.setPseudo(pseudo.getText().toString().trim());
                u.setPassword(mdp.getText().toString().trim());

                try {

                    /*if(um.getUser(pseudo.getText().toString().trim()).equals(b)){

                        Toast toast = Toast.makeText(SignIn.this, "Wesh " + pseudo, Toast.LENGTH_SHORT);
                        toast.show();
                        Intent retour = new Intent(SignIn.this, MainActivity.class);
                        startActivity(retour);
                    }else {
                        Toast toast = Toast.makeText(SignIn.this, "Problème avec la base", Toast.LENGTH_SHORT);
                        toast.show();
                    }*/
                    //User tst = um.getUser(u.getPseudo(),u.getPassword());
                    //if(tst.getPseudo().equals(u.getPseudo())){
                        Toast toast = Toast.makeText(SignIn.this, "Bonjour " + pseudo.getText().toString().trim(), Toast.LENGTH_SHORT);
                        toast.show();
                        Intent accueil = new Intent(SignIn.this, Home.class);
                        startActivity(accueil);
                    //}

               //     um.close();
                }catch(Exception e){
                    e.printStackTrace();
                }

            }


        });
    }
}
