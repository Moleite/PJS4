package com.oklm_room.data.model;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class User {

    private int id_user;
    private String last_name;
    private String first_name;
    private String pseudo;
    private String password;
    private int right;
    private int reservations;

    public User(int id_user, String last_name, String first_name, String pseudo, String password, int right, int reservations) {
        this.id_user = id_user;
        this.last_name = last_name;
        this.first_name = first_name;
        this.pseudo = pseudo;
        this.password = password;
        this.right = right;
        this.reservations = reservations;
    }
    public User() {
        this.last_name = null;
        this.first_name = null;
        this.pseudo = null;
        this.password = null;
        this.right=1;
        this.reservations = 0;
    }


    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRight() {
        return right;
    }

    public void setRight(int right) {
        this.right = right;
    }

    public int getReservations() {
        return reservations;
    }

    public void setReservations(int reservations) {
        this.reservations = reservations;
    }
}
