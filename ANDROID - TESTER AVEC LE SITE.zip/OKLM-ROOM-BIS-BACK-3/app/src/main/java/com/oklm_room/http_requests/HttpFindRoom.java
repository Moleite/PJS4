package com.oklm_room.http_requests;

import android.os.StrictMode;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by hadbi on 25/03/2016.
 */
public class HttpFindRoom {

   private ArrayList<NameValuePair> ListeParametre = new ArrayList<NameValuePair>();
   private  HttpPost httppost = new HttpPost(/*ULR DU SITE*/);

    public ArrayList ChercherSalle (String HeureD, String HeureF, String Date) {
        String ligne;
        ArrayList<String> tmp = new ArrayList<String>();
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            ListeParametre.add(new BasicNameValuePair("HeureD", HeureD));
            ListeParametre.add(new BasicNameValuePair("HeureF", HeureF));
            ListeParametre.add(new BasicNameValuePair("Date", Date));

            httppost.setEntity(new UrlEncodedFormEntity(ListeParametre));
            HttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(httppost);

            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            while ((ligne = reader.readLine()) != null) {
                tmp.add((ligne));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tmp;
    }
}
