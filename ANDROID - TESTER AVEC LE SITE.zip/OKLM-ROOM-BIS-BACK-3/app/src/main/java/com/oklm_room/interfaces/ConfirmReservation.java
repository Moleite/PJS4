package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.oklm_room.R;

public class ConfirmReservation extends Activity {

    private Button Change;
    private Button Cancel;
    private Button Confirm;

    final String EXTRA_RES = "res";
    final String EXTRA_H_BEGIN = "beg";
    final String EXTRA_H_END = "end";
    final String EXTRA_DATE = "date";
    final String EXTRA_RAM = "ram";
    final String EXTRA_SCREEN = "screen";
    final String EXTRA_PROCESSOR = "processor";
    final String EXTRA_USE = "useRoom";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_reservation);

        Intent intent = getIntent();

        TextView text = (TextView) findViewById(R.id.info_display);


        final String itemRes =  intent.getStringExtra(EXTRA_RES);
        final String h_begin = intent.getStringExtra(EXTRA_H_BEGIN);
        final String h_end = intent.getStringExtra(EXTRA_H_END);
        final String date = intent.getStringExtra(EXTRA_DATE);
        final String use= intent.getStringExtra(EXTRA_USE);
        final String ram= intent.getStringExtra(EXTRA_RAM);
        final String processor= intent.getStringExtra(EXTRA_PROCESSOR);
        final String screen= intent.getStringExtra(EXTRA_SCREEN);


        text.setText(intent.getStringExtra(EXTRA_USE) + "\n"
                +intent.getStringExtra(EXTRA_RES) +"\n"
                +intent.getStringExtra(EXTRA_DATE) + "\n"
                +intent.getStringExtra(EXTRA_H_BEGIN) + "\n"
                +intent.getStringExtra(EXTRA_H_END) + "\n"
                +intent.getStringExtra(EXTRA_SCREEN) + "\n"
                +intent.getStringExtra(EXTRA_RAM) + "\n"
                +intent.getStringExtra(EXTRA_PROCESSOR) + "\n");


        Change = (Button) findViewById(R.id.buttonChange);
        Cancel = (Button) findViewById(R.id.buttonCancel);
        Confirm = (Button) findViewById(R.id.buttonConf);

        Change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent reserv = new Intent(ConfirmReservation.this, Reservation.class);
                startActivity(reserv);
            }
        });

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent home = new Intent(ConfirmReservation.this, Home.class);
                startActivity(home);
            }
        });

        Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home_reserv = new Intent(ConfirmReservation.this, RoomsList.class);

                home_reserv.putExtra(EXTRA_RES, itemRes);
                home_reserv.putExtra(EXTRA_H_BEGIN, h_begin);
                home_reserv.putExtra(EXTRA_H_END, h_end);
                home_reserv.putExtra(EXTRA_DATE, date);
                home_reserv.putExtra(EXTRA_PROCESSOR, processor);
                home_reserv.putExtra(EXTRA_SCREEN, screen);
                home_reserv.putExtra(EXTRA_RAM, ram);
                home_reserv.putExtra(EXTRA_USE, use);
                startActivity(home_reserv);
            }
        });

    }
}
