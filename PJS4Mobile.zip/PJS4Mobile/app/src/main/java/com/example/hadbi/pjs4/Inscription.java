package com.example.hadbi.pjs4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Inscription extends ActionBarActivity {

    private Button retour;
    private Button inscription;
    private EditText pseudo;
    private EditText mdp;
    /* private personne bdd;*/
    private int verif;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        retour = (Button) findViewById(R.id.Retour);
        inscription = (Button) findViewById(R.id.Inscription);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);


        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(Inscription.this, MainActivity.class);
                startActivity(retour);
            }
        });

        inscription.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                /* verif = personne.inscription(pseudo.getText(),mdp.getText()) ;*/
                if(verif == 1) {
                    Intent reserv = new Intent(Inscription.this, MainActivity.class);
                    Toast toast = Toast.makeText(getApplicationContext(), "Vous avez bien été inscris, connectez vous pour continuer!", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    startActivity(reserv);
                }
                    else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Mauvais paramètre d'inscription, veuillez réessayer", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    pseudo.setText("");
                    mdp.setText("");
                }

            };
        });
    }
}
