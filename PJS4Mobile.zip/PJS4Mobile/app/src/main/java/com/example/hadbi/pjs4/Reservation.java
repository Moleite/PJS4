package com.example.hadbi.pjs4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Reservation extends ActionBarActivity {

    private TextView pseudo;
    private String Pseudorecup;
    private EditText DateR;
    private Button Confirmation;
    private EditText Salle;
    private EditText Performance;
    private EditText RAM;
    private CheckBox PerformanceC;
    private CheckBox RAMC;
    private int verif;
    /* public bdd personne;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);
        Pseudorecup = this.getIntent().getStringExtra("Pseudo");

        pseudo = (TextView) findViewById(R.id.PseudoTxt);
        pseudo.setText(Pseudorecup);

        DateR = (EditText) findViewById(R.id.DateReserv);
        Confirmation = (Button) findViewById(R.id.buttonConf);
        Salle = (EditText) findViewById(R.id.SalleTxt);
        Performance = (EditText) findViewById(R.id.PerfomanceTxt);
        RAM = (EditText) findViewById(R.id.RAMTxt);


        PerformanceC = (CheckBox) findViewById(R.id.PerformanceCheck);
        if(PerformanceC.isChecked()) {
            Performance.setVisibility(View.VISIBLE);
        }

        RAMC = (CheckBox) findViewById(R.id.RAMCheck);
        if(RAMC.isChecked()) {
            RAM.setVisibility(View.VISIBLE);
        }




        Confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* TODO: verif = personne.reservation(Salle.getText(), Confirmation.getText(),...)*/
                Intent reservation = new Intent(Reservation.this, ListeSalle.class);
                    reservation.putExtra("Salle",Salle.getText());
                    reservation.putExtra("Date",DateR.getText());

                    if(Performance.getVisibility()==View.VISIBLE){
                        reservation.putExtra("Performance",Performance.getText());
                    }
                    if(RAM.getVisibility()==View.VISIBLE) {
                        reservation.putExtra("RAM",RAM.getText());
                    }

                    startActivity(reservation);

            }
        });

        }
    }


