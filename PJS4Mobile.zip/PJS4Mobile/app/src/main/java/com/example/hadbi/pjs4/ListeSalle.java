package com.example.hadbi.pjs4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class ListeSalle extends ActionBarActivity {

    private String Salle;
    private String Date;
    private String Performance;
    private String RAM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_salle);

        Salle = this.getIntent().getStringExtra("Salle");
        Date = this.getIntent().getStringExtra("Date");
        if(this.getIntent().getStringExtra("Performance") != null) {
           Performance = this.getIntent().getStringExtra("Performance");
        }
        if(this.getIntent().getStringExtra("Performance") != null) {
            RAM = this.getIntent().getStringExtra("RAM");
        }


    }

}
