package com.example.hadbi.pjs4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class Connexion extends ActionBarActivity {

    private Button retour;
    private Button connexion;
    private EditText pseudo;
    private EditText mdp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        retour = (Button) findViewById(R.id.Retour);
        connexion = (Button) findViewById(R.id.Connexion);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);





        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(Connexion.this, MainActivity.class);
                startActivity(retour);
            }
        });


        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View V) {

                Intent connexion = new Intent(Connexion.this, Reservation.class);
                startActivity(connexion);
            }
        });
    }


}