package com.oklm_room.interfaces;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.oklm_room.MainActivity;
import com.oklm_room.R;
import com.oklm_room.errors.ErrorSignUp;
import com.oklm_room.http_requests.HttpSignUp;

public class SignUp extends AppCompatActivity {
    private Button retour;
    private Button inscription;
    private EditText pseudo;
    private EditText mdp;
    private EditText nom;
    private EditText prenom;
    private HttpSignUp conn = new HttpSignUp();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        retour = (Button) findViewById(R.id.Retour);
        inscription = (Button) findViewById(R.id.Inscription);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);
        nom = (EditText) findViewById(R.id.Nom);
        prenom = (EditText) findViewById(R.id.Prenom);


        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(SignUp.this, MainActivity.class);
                startActivity(retour);
            }
        });

        inscription.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                try {
                    conn.inscription(nom.getText().toString(), prenom.getText().toString(), pseudo.getText().toString(), mdp.getText().toString());
                    Intent reserv = new Intent(SignUp.this, MainActivity.class);
                    Toast toast = Toast.makeText(getApplicationContext(), "Vous avez bien été inscris, connectez vous pour continuer!", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    startActivity(reserv);

                } catch (ErrorSignUp e) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Mauvais paramètre d'inscription, veuillez réessayer", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    pseudo.setText("");
                    mdp.setText("");
                }
            }

            ;
        });
    }
}
