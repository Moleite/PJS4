-- --------------------------------------------------------
-- Hôte :                        127.0.0.1
-- Version du serveur:           5.6.20-log - MySQL Community Server (GPL)
-- SE du serveur:                Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour pjs4
CREATE DATABASE IF NOT EXISTS `pjs4` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pjs4`;


-- Export de la structure de table pjs4. reservations
CREATE TABLE IF NOT EXISTS `reservations` (
  `IdReservation` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11),
  `RoomId` int(11),
  `Start` time,
  `End` time,
  `Date` date DEFAULT NULL,
  PRIMARY KEY (`IdReservation`),
  KEY `FK_reservations_users` (`UserId`),
  KEY `FK_reservations_rooms` (`RoomId`),
  CONSTRAINT `FK_reservations_rooms` FOREIGN KEY (`RoomId`) REFERENCES `rooms` (`IdRoom`),
  CONSTRAINT `FK_reservations_users` FOREIGN KEY (`UserId`) REFERENCES `users` (`IdUser`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Export de données de la table pjs4.reservations : ~3 rows (environ)
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;


-- Export de la structure de table pjs4. rooms
CREATE TABLE IF NOT EXISTS `rooms` (
  `IdRoom` int(11) NOT NULL AUTO_INCREMENT,
  `NbRoom` varchar(50) NOT NULL,
  `NbSeat` int(11) NOT NULL,
  `Reserved` tinyint(4) NOT NULL,
  `Screen` varchar(50) DEFAULT NULL,
  `Processor` varchar(50) DEFAULT NULL,
  `Ram` varchar(50) DEFAULT NULL,
  `FloorId` int(11) NOT NULL,
  PRIMARY KEY (`IdRoom`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Export de données de la table pjs4.rooms : ~6 rows (environ)
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` (`IdRoom`, `NbRoom`, `NbSeat`, `Reserved`, `Screen`, `Processor`, `Ram`, `FloorId`) VALUES
	(1, '1', 1, 0, NULL, NULL, NULL, 1),
	(2, '2', 2, 0, NULL, NULL, NULL, 1),
	(3, '5', 29, 0, NULL, NULL, NULL, 2),
	(4, '3', 25, 0, NULL, NULL, NULL, 2),
	(5, '1', 26, 0, NULL, NULL, NULL, 3),
	(6, '7', 18, 0, NULL, NULL, NULL, 3),
	(7, '1', 5, 0, NULL, NULL, NULL, 0);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;


-- Export de la structure de table pjs4. users
CREATE TABLE IF NOT EXISTS `users` (
  `IdUser` int(11) NOT NULL AUTO_INCREMENT,
  `Lastname` varchar(50) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Pseudo` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` varchar(50) NOT NULL,
  `Reservations` int(11) DEFAULT '0',
  PRIMARY KEY (`IdUser`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Export de données de la table pjs4.users : ~4 rows (environ)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`IdUser`, `Lastname`, `Firstname`, `Pseudo`, `Password`, `Role`, `Reservations`) VALUES
	(1, 'Lastname1', 'Firstname1', 'test1', 'test1', '1', 0),
	(2, 'Lastname2', 'Firstname2', 'test2', 'test2', '1', 0),
	(3, 'oklm', 'oklm', 'oklm', 'oklm', '1', 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
users