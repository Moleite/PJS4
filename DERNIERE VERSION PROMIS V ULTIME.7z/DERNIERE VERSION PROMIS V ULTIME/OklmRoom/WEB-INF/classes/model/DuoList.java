package model;

import java.util.ArrayList;
import java.util.List;

public class DuoList {
	private List<List<Room>> rooms = new ArrayList<List<Room>>();
	private List<List<Integer>> nbSeatLefts = new ArrayList<List<Integer>>();
	
	public DuoList(List<List<Room>> rooms, List<List<Integer>> nbSeatLefts) {
		this.rooms = rooms;
		this.nbSeatLefts = nbSeatLefts;
	}
	
	public List<List<Room>> getRooms() {
		return this.rooms;
	}
	
	public List<List<Integer>> getNbSeatLefts() {
		return this.nbSeatLefts;
	}
}
