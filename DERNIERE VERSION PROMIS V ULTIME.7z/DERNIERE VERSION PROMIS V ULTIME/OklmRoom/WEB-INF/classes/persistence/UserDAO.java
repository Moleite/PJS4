package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exception.UserAlreadyExistException;
import exception.UserNotFoundException;
import model.User;

/**
 * DataAccessObject en charge de g�rer la r�cup�ration des utilisateurs
 */
public class UserDAO {
	
	private Connection connection;
	private static UserDAO instance = new UserDAO();
	
	/**
	 * Cr�er un nouvel accesseur d'utilisateur
	 */
	private UserDAO() {
		try {
			this.connection = DataBase.getConnection();
		} catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Obtenir l'instance d'UserDAO (Singleton)
	 * 
	 * @return l'instance d'UserDAO
	 */
	public static UserDAO getInstance() {
		return instance;
	}
	
	
	/**
	 * Ajouter un utilisateur a la base de donn�e
	 * 
	 * @param user l'utilisateur � ajouter a la base de donn�e
	 */
	public void addUser(User user) throws UserAlreadyExistException {
		try {
			String request = "INSERT INTO USERS (Lastname, Firstname, Pseudo, Password, Role, Reservations) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = this.connection.prepareStatement(request);
			preparedStatement.setString(1, user.getLastName());
			preparedStatement.setString(2, user.getFirstName());
			preparedStatement.setString(3, user.getPseudo());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.setString(5, user.getRight());
			preparedStatement.setInt(6, user.getReservations());			
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserAlreadyExistException();
		}
	}
	
	/**
	 * Trouver un utilisateur grace a son num�ro unique
	 * 
	 * @param idUser Login de l'utilisateur
	 * @return l'utilisateur qui correspond ou l�ve une exception si il ne trouve pas d'utilisateur
	 */
	public User findUser (int idUser) throws UserNotFoundException {
		try {
			User user = null;
			String requete = "SELECT * FROM USERS WHERE idUser = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);
			preparedStatement.setInt(1, idUser);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				String lastName_found = resultats.getString("lastname");
				String firstName_found = resultats.getString("firstname");
				String pseudo_found = resultats.getString("pseudo");
				String password_found = resultats.getString("password");
				String right_found = resultats.getString("role");
				user = new User(idUser, lastName_found, firstName_found, pseudo_found, password_found, right_found);
			}
			
			if(user != null)
				return user;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new UserNotFoundException();
	}
	
	/**
	 * Trouver un utilisateur grace a son pseudo et son mot de passe
	 * 
	 * @param pseudo Login de l'utilisateur
	 * @param password Mot de passe de l'utilisateur
	 * @return l'utilisateur qui correspond ou l�ve une exception si il ne trouve pas d'utilisateur
	 */
	public User findUser(String pseudo, String password) throws UserNotFoundException {
		try {
			User user = null;
			String request = "SELECT * FROM USERS WHERE pseudo = ? AND password = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(request);
			preparedStatement.setString(1, pseudo);
			preparedStatement.setString(2, password);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				int idUser_found = resultats.getInt("idUser");
				String lastName_found = resultats.getString("lastname");
				String firstName_found = resultats.getString("firstname");
				String pseudo_found = resultats.getString("pseudo");
				String password_found = resultats.getString("password");
				String right_found = resultats.getString("role");
				user = new User(idUser_found, lastName_found, firstName_found, pseudo_found, password_found, right_found);
			}
			
			if(user != null)
				return user;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new UserNotFoundException();
	}

}
