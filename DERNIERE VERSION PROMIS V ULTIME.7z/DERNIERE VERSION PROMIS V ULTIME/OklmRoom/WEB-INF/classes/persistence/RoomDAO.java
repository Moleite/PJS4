package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exception.NotFoundException;
import exception.RoomNotFoundException;
import model.DuoList;
import model.Room;

/**
 * DataAccessObject en charge de g�rer la r�cup�ration des salles
 */
public class RoomDAO {
	
	private Connection connection;
	private static RoomDAO instance = new RoomDAO();
	
	/**
	 * Cr�er un nouvel accesseur de Rooms
	 */
	private RoomDAO() {
		try {
			this.connection = DataBase.getConnection();
		} catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Obtenir l'instance de RoomDAO (Singleton)
	 * 
	 * @return l'instance de RoomDAO
	 */
	public static RoomDAO getInstance() {
		return instance;
	}
	
	
	/**
	 * Ajouter une Room � la base de donn�e
	 * 
	 * @param room Room � ajouter � la base de donn�e
	 */
	public void addRoom(Room room) {
		try {
			String requete = "INSERT INTO ROOMS (NbRoom, NbSeat, Screen, Processor, Ram, FloorId) VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = this.connection.prepareStatement(requete);

			preparedStatement.setString(1, room.getNbRoom());
			preparedStatement.setInt(2, room.getNbSeat());
			preparedStatement.setString(3, room.getScreen());
			preparedStatement.setString(4, room.getProcessor());
			preparedStatement.setString(5, room.getRam());
			preparedStatement.setInt(6, room.getFloorId());

			preparedStatement.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Retrouver une salle � partir de son num�ro unique 
	 * 
	 * @param idRoom Le num�ro de la salle
	 * @return la salle correspondante
	 * @throws NotFoundException si la salle n'existe pas
	 */
	public Room findRoom(int idRoom) throws NotFoundException {
		Room room = null;
		
		try {
			String request = "SELECT * FROM ROOMS WHERE idRoom = ?";
			PreparedStatement preparedStatement = this.connection.prepareStatement(request);
			preparedStatement.setInt(1, idRoom);
			ResultSet resultats = preparedStatement.executeQuery();
			
			while (resultats.next()) {
				room = new Room(idRoom, resultats.getString("nbRoom"), resultats.getInt("nbSeat"), resultats.getString("screen"),
						resultats.getString("processor"),resultats.getString("ram"), resultats.getInt("floorId"));
			}
			
			if(room != null)
				return room;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		throw new RoomNotFoundException();
	}
	
	/**
	 * R�cup�rer la liste des salles disponibles � une date donn�e
	 * 
	 * @param date La date donn�e
	 * @return la liste des salles voulues
	 * @throws NotFoundException 
	 */
	public DuoList findRooms(String date, String hourStart, String hourEnd) throws NotFoundException {
		int nbFloors = 0;
		List<List<Room>> rooms = new ArrayList<List<Room>>();
		List<List<Integer>> nbSeatLefts = new ArrayList<List<Integer>>();
		
		//On r�cup�re le nombre d'�tages
		try {
			String request1 = "SELECT * FROM ROOMS ORDER BY FloorId DESC";
			PreparedStatement preparedStatement1 = this.connection.prepareStatement(request1);
			ResultSet resultats1 = preparedStatement1.executeQuery();
			
			if (resultats1.next()){
				nbFloors = resultats1.getInt("FloorId");
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		//On ins�re dans la liste d'�tages (ordre croissant), la liste des salles (ordre croissant)
		for(int i=0; i<=nbFloors; i++){
			try {
				String request2 = "SELECT * FROM ROOMS ORDER BY FloorId, NbRoom";
				PreparedStatement preparedStatement2 = this.connection.prepareStatement(request2);
				ResultSet resultats2 = preparedStatement2.executeQuery();
			
				while (resultats2.next()){
					if(i == resultats2.getInt("FloorId")) {
						int nbSeatTaken = 0;
						
						try {
							String request3 = "SELECT COUNT(*) FROM RESERVATIONS WHERE RoomId = ? AND Date = ? AND (((CAST(? As Time) >= Start) AND (CAST(? As Time) <= End)) OR ((CAST(? As Time) >= Start) AND (CAST(? As Time) <= End)) OR ((CAST(? AS Time) < Start) AND (CAST(? As Time) > End)))";
							PreparedStatement preparedStatement3 = this.connection.prepareStatement(request3);
							preparedStatement3.setInt(1, resultats2.getInt("IdRoom"));
							preparedStatement3.setString(2, date);
							preparedStatement3.setString(3, hourStart);
							preparedStatement3.setString(4, hourStart);
							preparedStatement3.setString(5, hourEnd);
							preparedStatement3.setString(6, hourEnd);
							preparedStatement3.setString(7, hourStart);
							preparedStatement3.setString(8, hourEnd);
							ResultSet resultats3 = preparedStatement3.executeQuery();
						
							while (resultats3.next()){
								nbSeatTaken = resultats3.getInt("COUNT(*)");
							}
						
						} catch (SQLException e3) {
							e3.printStackTrace();
						}
						ArrayList<Integer> listFloors = new ArrayList<Integer>();
						nbSeatLefts.add(listFloors);
						nbSeatLefts.get(i).add(resultats2.getInt("nbSeat") - nbSeatTaken);
						
						Room room = findRoom(resultats2.getInt("idRoom"));
						ArrayList<Room> listRooms = new ArrayList<Room>();
						rooms.add(listRooms);
						if ((resultats2.getInt("nbSeat") - nbSeatTaken) > 0) {
							rooms.get(i).add(room);
						}

					}
				}
			
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		DuoList duo = new DuoList(rooms, nbSeatLefts);
		return duo;
	}
	
	public static void main(String[] args) throws NotFoundException {
		List<List<Integer>> nbSeatLefts = new ArrayList<List<Integer>>();
		
		ArrayList<Integer> listFloors = new ArrayList<Integer>();
		
		nbSeatLefts.add(listFloors);
		nbSeatLefts.get(0);
		
		System.out.println(new RoomDAO().findRooms("2016/03/31", "05:00:00", "09:00:00").getNbSeatLefts().get(1));
		
	}

}