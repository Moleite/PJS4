package com.oklm_room.data.model;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class Room {

    private int id_room;
    private String nb_room;
    private int nb_seat;
    private boolean reserved;
    private String screen;
    private String processor;
    private String ram;
    private int floor_id;

    public Room(int id_room, String nb_room, int nb_seat, boolean reserved, String screen, String processor, String ram, int floor_id) {
        this.id_room = id_room;
        this.nb_room = nb_room;
        this.nb_seat = nb_seat;
        this.reserved = reserved;
        this.screen = screen;
        this.processor = processor;
        this.ram = ram;
        this.floor_id = floor_id;
    }

    public int getId_room() {
        return id_room;
    }

    public void setId_room(int id_room) {
        this.id_room = id_room;
    }

    public String getNb_room() {
        return nb_room;
    }

    public void setNb_room(String nb_room) {
        this.nb_room = nb_room;
    }

    public int getNb_seat() {
        return nb_seat;
    }

    public void setNb_seat(int nb_seat) {
        this.nb_seat = nb_seat;
    }

    public boolean isReserved() {
        return reserved;
    }

    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public int getFloor_id() {
        return floor_id;
    }

    public void setFloor_id(int floor_id) {
        this.floor_id = floor_id;
    }
}
