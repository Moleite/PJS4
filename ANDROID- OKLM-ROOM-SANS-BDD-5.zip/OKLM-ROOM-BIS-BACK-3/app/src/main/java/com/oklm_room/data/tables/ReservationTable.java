package com.oklm_room.data.tables;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class ReservationTable {

    public static final String RESERVATIONS_TABLE_NAME = "RESERVATIONS";
    //Id
    public static final String RESERVATIONS_ID = "idreservation";
    //Ident de l'user
    public static final String RESERVATIONS_USERS_ID = "userid";
    //Ident de la salle
    public static final String RESERVATIONS_ROOMS_ID = "roomid";
    //Heure de début
    public static final String RESERVATIONS_START = "start";
    //Heure de fin
    public static final String RESERVATIONS_END = "end";
    //Jour
    public static final String RESERVATIONS_DAY = "day";

    //Requête pour créer la table reservations
    public static final String RESERVATIONS_TABLE_CREATE = "CREATE TABLE " + RESERVATIONS_TABLE_NAME + " (" +
            RESERVATIONS_ID + " INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY, " +
            RESERVATIONS_USERS_ID + " INTEGER NOT NULL, " +
            RESERVATIONS_ROOMS_ID + " INTEGER NOT NULL, " +
            RESERVATIONS_START + " TIME  NOT NULL, " +
            RESERVATIONS_END + " TIME NOT NULL, " +
            RESERVATIONS_DAY+ " DATE NOT NULL); ";

    //Requête pour supprimer la table reservations
    public static final String RESERVATIONS_TABLE_DROP = "DROP TABLE IF EXISTS " + RESERVATIONS_TABLE_NAME + ";";


}
