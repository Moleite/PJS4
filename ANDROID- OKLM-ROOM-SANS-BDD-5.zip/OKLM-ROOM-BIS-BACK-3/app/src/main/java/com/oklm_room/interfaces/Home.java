package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.oklm_room.R;

public class Home extends Activity {

    private Button consult;
    private Button reserv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        consult = (Button) findViewById(R.id.Consulter);
        reserv = (Button) findViewById(R.id.Reserver);


        consult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cons = new Intent(Home.this, RoomsList.class);
                startActivity(cons);

            }
        });

        reserv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent reser = new Intent(Home.this, Reservation.class);
                startActivity(reser);

            }
        });
    }
}
