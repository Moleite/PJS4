package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.oklm_room.R;

import java.util.ArrayList;
import java.util.List;

public class Reservation extends Activity {


    private EditText DateR;

    private Button Confirmation;
    private Button Accueil;

    private RadioButton Cours;
    private RadioButton LibreServ;

    private CheckBox Processor;
    private CheckBox RAM;
    private CheckBox Screen;

    private Spinner hBegin;
    private Spinner hEnd;

    final String EXTRA_H_BEGIN = "beg";
    final String EXTRA_H_END = "end";
    final String EXTRA_DATE = "date";
    final String EXTRA_RAM = "ram";
    final String EXTRA_SCREEN = "screen";
    final String EXTRA_PROCESSOR = "processor";
    final String EXTRA_USE = "useRoom";



    private int verif;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);
        /*Pseudorecup = this.getIntent().getStringExtra("Pseudo");

        pseudo = (TextView) findViewById(R.id.PseudoTxt);
        pseudo.setText(Pseudorecup);

       */

        Processor = (CheckBox) findViewById(R.id.ProcessorCheck);
        RAM = (CheckBox) findViewById(R.id.RAMCheck);
        Screen = (CheckBox) findViewById(R.id.ScreenCheck);

        Cours = (RadioButton) findViewById(R.id.CoursCHECKED);
        LibreServ = (RadioButton) findViewById(R.id.LibreServiceCHECKED);

        DateR = (EditText) findViewById(R.id.DateReserv);

        Confirmation = (Button) findViewById(R.id.buttonConf);
        Accueil = (Button) findViewById(R.id.buttonRetour);
        //Les crénaux
        hBegin = (Spinner) findViewById(R.id.beginList);
        hEnd = (Spinner) findViewById(R.id.endList);
      //  creno.setOnItemClickListener(this);

        List<String> hour = new ArrayList<String>();
        hour.add("8h");
        hour.add("8h30");
        hour.add("9h");
        hour.add("9h30");
        hour.add("10h");
        hour.add("10h30");
        hour.add("11h");
        hour.add("11h30");
        hour.add("12h");
        hour.add("12h30");
        hour.add("13h");
        hour.add("13h30");
        hour.add("14h");
        hour.add("14h30");
        hour.add("15h");
        hour.add("15h30");
        hour.add("16h");
        hour.add("16h30");
        hour.add("17h");
        hour.add("17h30");
        hour.add("18h");
        hour.add("18h30");
        hour.add("19h");
        hour.add("19h30");

        ArrayAdapter<String> dataAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, hour);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        hBegin.setAdapter(dataAdapter);
        hEnd.setAdapter(dataAdapter);


       /* PerformanceC = (CheckBox) findViewById(R.id.PerformanceCheck);
        if(PerformanceC.isChecked()) {
            Performance.setVisibility(View.VISIBLE);
        }

        RAMC = (CheckBox) findViewById(R.id.RAMCheck);
        if(RAMC.isChecked()) {
            RAM.setVisibility(View.VISIBLE);
        }

        */
        final Intent disp = new Intent(Reservation.this, AvailableRoomsList.class);


        hBegin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String hbegin = ((TextView)view).getText().toString();
                Toast toast = Toast.makeText(Reservation.this, "Débute à " + hbegin, Toast.LENGTH_SHORT);
                toast.show();
                disp.putExtra(EXTRA_H_BEGIN, "Début : "+hbegin);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        hEnd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String h_end = ((TextView) view).getText().toString();
                Toast toast = Toast.makeText(Reservation.this, "Termine à " + h_end, Toast.LENGTH_SHORT);
                toast.show();
                disp.putExtra(EXTRA_H_END, "Fin : " + h_end);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final boolean checked = ((RadioButton) Cours).isChecked();

        Confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(disp);
                disp.putExtra(EXTRA_DATE, "Date : " + DateR.getText().toString());

                if (Processor.isChecked()) {
                    disp.putExtra(EXTRA_PROCESSOR, "Processeur > 2.8GHz : OUI");
                }else{
                    disp.putExtra(EXTRA_PROCESSOR, "Processeur : Pas demandé");
                }
                if (RAM.isChecked()) {
                    disp.putExtra(EXTRA_RAM, "RAM > 4 Go : OUI");
                }else{
                    disp.putExtra(EXTRA_RAM, "RAM : Pas demandé");
                }
                if (Screen.isChecked()) {
                    disp.putExtra(EXTRA_SCREEN, "Ecran > 20'' : OUI");
                }else{
                    disp.putExtra(EXTRA_RAM, "Ecran : Pas demandé");
                }

                if (checked) {
                    disp.putExtra(EXTRA_USE, "Utilisation de la salle : Cours");
                } else {
                    disp.putExtra(EXTRA_USE, "Utilisation de la salle : Libre Service");
                }
            }
        });

        Accueil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(Reservation.this, Home.class);
                startActivity(home);
            }
        });


    }

}
