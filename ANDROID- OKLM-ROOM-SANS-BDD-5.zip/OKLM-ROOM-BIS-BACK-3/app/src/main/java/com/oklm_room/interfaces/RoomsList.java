package com.oklm_room.interfaces;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.oklm_room.R;

public class RoomsList extends ActionBarActivity {

    final String EXTRA_RES = "res";
    final String EXTRA_H_BEGIN = "beg";
    final String EXTRA_H_END = "end";
    final String EXTRA_DATE = "date";
    final String EXTRA_RAM = "ram";
    final String EXTRA_SCREEN = "screen";
    final String EXTRA_PROCESSOR = "processor";
    final String EXTRA_USE = "useRoom";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms_list);
      //  ListView mListView = (ListView) findViewById(R.id.listView);

        Intent intent = getIntent();

        TextView text = (TextView) findViewById(R.id.info_display_reserv);

        text.setText(intent.getStringExtra(EXTRA_USE) + "\n"
                +intent.getStringExtra(EXTRA_RES) +"\n"
                +intent.getStringExtra(EXTRA_DATE) + "\n"
                +intent.getStringExtra(EXTRA_H_BEGIN) + "\n"
                +intent.getStringExtra(EXTRA_H_END) + "\n"
                +intent.getStringExtra(EXTRA_SCREEN) + "\n"
                +intent.getStringExtra(EXTRA_RAM) + "\n"
                +intent.getStringExtra(EXTRA_PROCESSOR) + "\n");
    }
}
