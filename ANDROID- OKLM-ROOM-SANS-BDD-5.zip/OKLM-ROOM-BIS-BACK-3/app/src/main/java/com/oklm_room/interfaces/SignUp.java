package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.oklm_room.MainActivity;
import com.oklm_room.R;
import com.oklm_room.data.manager.UserManager;
import com.oklm_room.data.model.User;

public class SignUp extends Activity {

    private Button retour;
    private Button inscription;
    EditText pseudo;
    EditText mdp;
    EditText nom;
    EditText prenom;

    UserManager um;
    User u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        retour = (Button) findViewById(R.id.Retour);
        inscription = (Button) findViewById(R.id.Inscription);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);
        nom = (EditText) findViewById(R.id.Nom);
        prenom = (EditText) findViewById(R.id.Prenom);

        //um = new UserManager(this);

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(SignUp.this, MainActivity.class);
                startActivity(retour);
            }
        });

        inscription.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

              //  um.open();
                u= new User();
                u.setFirst_name(prenom.getText().toString().trim());
                u.setLast_name(nom.getText().toString().trim());
                u.setPseudo(pseudo.getText().toString().trim());
                u.setPassword(mdp.getText().toString().trim());

                try {
                 //   um.addUser(u);
                    //long lg = um.addUser(u);
                    //Toast toast = Toast.makeText(SignUp.this, "Ajouté à la ligne" + lg, Toast.LENGTH_SHORT);
                    Toast toast = Toast.makeText(SignUp.this, "Vous êtes inscrit "+prenom.getText().toString().trim()+" "+nom.getText().toString().trim()+" !", Toast.LENGTH_LONG);
                    toast.show();
                    Intent connect = new Intent(SignUp.this, SignIn.class);
                    startActivity(connect);
                  //  um.close();
                   // Toast toast = Toast.makeText(this, "ADDED", Toast.LENGTH_SHORT);
                    //toast.show();
                }catch(Exception e){
                    e.printStackTrace();
                    Toast toast = Toast.makeText(SignUp.this, "Changez votre Pseudo !", Toast.LENGTH_LONG);
                    toast.show();
                }

            }


        });
    }
}
