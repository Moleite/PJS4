package com.oklm_room.data.tables;

/**
 * Created by Jean-Jacques on 26/03/2016.
 */
public class RoomTable {

    public static final String ROOMS_TABLE_NAME = "ROOMS";
    //Id
    public static final String ROOMS_ID = "idroom";
    //Nom
    public static final String ROOMS_NB_ROOM = "nbroom";
    //Nombre de places
    public static final String ROOMS_NB_SEAT = "nbseat";
    //Reservée
    public static final String ROOMS_RESERVED = "reserved";
    //Taille écran
    public static final String ROOMS_SCREEN = "screen";
    //Processeur
    public static final String ROOMS_PROCESSOR = "processor";
    //Mémoire RAM
    public static final String ROOMS_RAM = "ram";
    //Ident de l'étage
    public static final String ROOMS_FLOOR = "floorid";


    //Requête pour créer la table rooms
    public static final String ROOMS_TABLE_CREATE = "CREATE TABLE " + ROOMS_TABLE_NAME + " (" +
            ROOMS_ID + " INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY, " +
            ROOMS_NB_ROOM + " TEXT NOT NULL, " +
            ROOMS_NB_SEAT + " INTEGER NOT NULL, " +
            ROOMS_RESERVED + " TEXT  NOT NULL, " +
            ROOMS_SCREEN + " TEXT NOT NULL, " +
            ROOMS_PROCESSOR + " TEXT NOT NULL, "+
            ROOMS_RAM + " TEXT NOT NULL, " +
            ROOMS_FLOOR+ " INTEGER NOT NULL); ";

    //Requête pour supprimer la table rooms
    public static final String ROOMS_TABLE_DROP = "DROP TABLE IF EXISTS " + ROOMS_TABLE_NAME + ";";
}
