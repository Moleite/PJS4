package com.example.hadbi.pjs4.Erreur;

/**
 * Created by hadbi on 25/03/2016.
 */
public class ErreurReservation extends Exception {
    public ErreurReservation() {

    }
}
