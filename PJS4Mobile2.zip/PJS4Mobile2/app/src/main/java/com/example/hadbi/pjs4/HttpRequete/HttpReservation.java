package com.example.hadbi.pjs4.HttpRequete;

import android.os.StrictMode;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by hadbi on 25/03/2016.
 */
public class HttpReservation {

    ArrayList<NameValuePair> ListeParametre = new ArrayList<NameValuePair>();
    HttpPost httppost = new HttpPost(/*ULR DU SITE*/);

    public void reservation (String HeureD, String HeureF, String Date) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    ListeParametre.add(new BasicNameValuePair("HeureD", HeureD));
                    ListeParametre.add(new BasicNameValuePair("HeureF", HeureF));
                    ListeParametre.add(new BasicNameValuePair ("Date", Date));

                    httppost.setEntity(new UrlEncodedFormEntity(ListeParametre));
                    HttpClient httpClient = new DefaultHttpClient();
                    httpClient.execute(httppost);
                } catch (IOException e) {
                    e.printStackTrace();
            }
                
};
}
