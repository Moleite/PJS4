package com.example.hadbi.pjs4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hadbi.pjs4.Erreur.ErreurInscription;
import com.example.hadbi.pjs4.HttpRequete.HttpInscription;


public class Inscription extends Activity {

    private Button retour;
    private Button inscription;
    private EditText pseudo;
    private EditText mdp;
    private HttpInscription conn = new HttpInscription();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        retour = (Button) findViewById(R.id.Retour);
        inscription = (Button) findViewById(R.id.Inscription);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);


        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(Inscription.this, MainActivity.class);
                startActivity(retour);
            }
        });

        inscription.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                try {
                    conn.inscription(pseudo.getText().toString(),mdp.getText().toString());
                    Intent reserv = new Intent(Inscription.this, MainActivity.class);
                    Toast toast = Toast.makeText(getApplicationContext(), "Vous avez bien été inscris, connectez vous pour continuer!", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    startActivity(reserv);

                } catch (ErreurInscription e) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Mauvais paramètre d'inscription, veuillez réessayer", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    pseudo.setText("");
                    mdp.setText("");
                }
            };
        });
    }
}
