package com.example.hadbi.pjs4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hadbi.pjs4.Erreur.ErreurConnexion;
import com.example.hadbi.pjs4.HttpRequete.HttpConnexion;


public class Connexion extends Activity {

    private Button retour;
    private Button connexion;
    private EditText pseudo;
    private EditText mdp;
    private HttpConnexion conn = new HttpConnexion();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connexion);

        retour = (Button) findViewById(R.id.Retour);
        connexion = (Button) findViewById(R.id.Connexion);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);



        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(Connexion.this, MainActivity.class);
                startActivity(retour);
            }
        });


        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View V) {
                try {
                    conn.connexion(pseudo.getText().toString(), mdp.getText().toString());
                    Intent connexion = new Intent(Connexion.this, Reservation.class);
                    connexion.putExtra("Pseudo", pseudo.getText());
                    startActivity(connexion);
                }
                catch(ErreurConnexion e) {
                    Toast toast = Toast.makeText(Connexion.this, "Mauvais identifiants de connexion, veuillez réssayer", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    pseudo.setText("");
                    mdp.setText("");
                }
            }
    });
    }
}