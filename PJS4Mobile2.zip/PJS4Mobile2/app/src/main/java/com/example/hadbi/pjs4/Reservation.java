package com.example.hadbi.pjs4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hadbi.pjs4.HttpRequete.HttpReservation;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Reservation extends Activity {

    private TextView pseudo;
    private String Pseudorecup;
    private String debut;
    private String fin;
    private EditText DateR;
    private Button Confirmation;
    private EditText Performance;
    private EditText RAM;
    private EditText HeureF;
    private EditText HeureD;
    private CheckBox PerformanceC;
    private CheckBox RAMC;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        Pseudorecup = this.getIntent().getStringExtra("Pseudo");
        pseudo = (TextView) findViewById(R.id.PseudoTxt);
        pseudo.setText(Pseudorecup);

        DateR = (EditText) findViewById(R.id.DateReserv);
        HeureF = (EditText) findViewById(R.id.Heurefin);
        HeureD = (EditText) findViewById(R.id.Heuredéb);
        Confirmation = (Button) findViewById(R.id.buttonConf);
        Performance = (EditText) findViewById(R.id.PerfomanceTxt);
        RAM = (EditText) findViewById(R.id.RAMTxt);


        PerformanceC = (CheckBox) findViewById(R.id.PerformanceCheck);
        if (PerformanceC.isChecked()) {
            Performance.setVisibility(View.VISIBLE);
        }

        RAMC = (CheckBox) findViewById(R.id.RAMCheck);
        if (RAMC.isChecked()) {
            RAM.setVisibility(View.VISIBLE);
        }


        SimpleDateFormat g = new SimpleDateFormat("HH:mm");
        debut = g.format(HeureF.getText());
        fin = g.format(HeureD.getText());


        Confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!DateR.equals("") || !debut.equals("") || !fin.equals("")) {
                    Intent reservation = new Intent(Reservation.this, ListeSalle.class);
                    reservation.putExtra("HeureDebut", debut);
                    reservation.putExtra("HeureFin", fin);
                    reservation.putExtra("Date", DateR.getText());

                    if (Performance.getVisibility() == View.VISIBLE) {
                        reservation.putExtra("Performance", Performance.getText());
                    }
                    if (RAM.getVisibility() == View.VISIBLE) {
                        reservation.putExtra("RAM", RAM.getText());
                    }

                    startActivity(reservation);

                } else {
                    Toast toast = Toast.makeText(Reservation.this, "Veuillez entrer des paramètres de réservation valide", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                }
            }
        });
    }
}


