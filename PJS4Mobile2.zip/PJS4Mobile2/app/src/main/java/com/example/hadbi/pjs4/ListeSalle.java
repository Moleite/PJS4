package com.example.hadbi.pjs4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.hadbi.pjs4.HttpRequete.HttpReservation;

import java.util.ArrayList;

public class ListeSalle extends Activity {

    private String Salle;
    private String Date;
    private String Performance;
    private String RAM;
    private String HeureD;
    private String HeureF;
    private ListView ListeSalle;
    private Button retourReserv;
    private ArrayList<String> Liste = new ArrayList<>();
    private HttpReservation conn = new HttpReservation();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_salle);

        HeureD = this.getIntent().getStringExtra("HeureDebut");
        HeureF = this.getIntent().getStringExtra("HeureFin");
        Date = this.getIntent().getStringExtra("Date");
        /*if(this.getIntent().getStringExtra("Performance") != null) {
           Performance = this.getIntent().getStringExtra("Performance");
        }
        if(this.getIntent().getStringExtra("RAM") != null) {
            RAM = this.getIntent().getStringExtra("RAM");
        }*/

        conn.reservation(HeureD, HeureF, Date);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.activity_list_item, Liste);
        ListeSalle = (ListView) findViewById(R.id.ListSalle);
        ListeSalle.setAdapter(adapter);

        retourReserv = (Button) findViewById(R.id.ButtonChang);

        retourReserv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Change = new Intent(ListeSalle.this, Reservation.class);
                startActivity(Change);
            }
        });
    }

}
