package model;

/**
 * Mod�le servant de support pour les salles
 */
public class Room {
	private int idRoom;
	private String nbRoom;
	private int nbSeat;
	private String screen;
	private String processor;
	private String ram;
	private int floorId;
	
	private boolean reserved;
	
	/**
	 * Instancier une nouvelle salle sans id
	 * 
	 * @param nbRoom numero de la salle
	 * @param floorId etage de la salle
	 * @param screen taille des ecrans de la salle
	 * @param nbSeat nombre de places de la salle
	 * @param processor processeur des ordinateurs de la salle
	 * @param ram ram des ordinateurs de la salle
	 */	
	public Room(String nbRoom, int nbSeat, String screen, String processor, String ram, int floorId) {
		this.nbRoom = nbRoom;
		this.nbSeat = nbSeat;
		this.screen = screen;	
		this.processor = processor;
		this.ram = ram;
		this.floorId = floorId;
		
		this.reserved = false;
	}
	
	/**
	 * Instancier une nouvelle salle
	 * 
	 * @param nbRoom numero de la salle
	 * @param floorId etage de la salle
	 * @param screen taille des ecrans de la salle
	 * @param nbSeat nombre de places de la salle
	 * @param processor processeur des ordinateurs de la salle
	 * @param ram ram des ordinateurs de la salle
	 */	
	public Room(int idRoom, String nbRoom, int nbSeat, String screen, String processor, String ram, int floorId) {
		this.idRoom = idRoom;
		this.nbRoom = nbRoom;
		this.nbSeat = nbSeat;
		this.screen = screen;	
		this.processor = processor;
		this.ram = ram;
		this.floorId = floorId;
		
		this.reserved = false;
	}
	
	/**
	 * R�cup�rer le num�ro unique de la salle
	 * 
	 * @return le num�ro de la salle
	 */
	public int getIdRoom() {
		return idRoom;
	}

	/**
	 * R�cup�rer le nom de la salle
	 * 
	 * @return le num�ro de la salle
	 */
	public String getNbRoom() {
		return nbRoom;
	}
	
	/**
	 * Savoir si la salle est deja r�serv�e ou pas
	 * 
	 * @return true si oui ou false sinon
	 */
	public boolean isReserved() {
		return reserved;
	}
	
	/**
	 * R�cup�rer le nombre de places de la salle
	 * 
	 * @return le nombre de places de la salle
	 */
	public int getNbSeat() {
		return nbSeat;
	}
	
	/**
	 * R�cup�rer l'etage de la salle
	 * 
	 * @return l'etage de la salle
	 */
	public int getFloorId() {
		return floorId;
	}
	
	/**
	 * R�cup�rer la taille des ecrans de la salle
	 * 
	 * @return la taille des ecrans de la salle
	 */
	public String getScreen() {
		return screen;
	}
	
	/**
	 * R�cup�rer le processeur des ordinateurs de la salle
	 * 
	 * @return le processeur des ordinateurs de la salle
	 */
	public String getProcessor() {
		return processor;
	}

	/**
	 * R�cup�rer la ram des ordinateurs de la salle
	 * 
	 * @return la ram des ordinateurs de la salle
	 */
	public String getRam() {
		return ram;
	}
	
	public String getRoomName() {
		return floorId + "-" + nbRoom;		
	}
	
}
