package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;

import exception.NotFoundException;
import model.Reservation;
import model.Room;
import model.Dispatcher;
import model.User;


public class ReservationController extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private Dispatcher dispatcher = Dispatcher.getInstance();

	/**
	 * Renvoie � l'action correspondante aux param�tres
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException { 
        String action = request.getParameter("action");
		action = (action == null) ? "index" : action;
		
		if(action.equals("listRooms"))
			this.listRoomsAction(request, response);
		else if(action.equals("reserve"))
			this.reserveAction(request, response);
		else if(action.equals("cancel"))
			this.cancelAction(request, response);
		else
			request.getRequestDispatcher("/views/error/404.jsp").forward(request, response);

	}
	
	/**
	 * Liste les rooms en fonction des param�tres du formulaire
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void listRoomsAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String date = request.getParameter("date");
		String hourStart = request.getParameter("hourStart");
		String hourEnd = request.getParameter("hourEnd");
		
		try {
			ArrayList<List<Room>> rooms  = (ArrayList<List<Room>>) dispatcher.getRooms(date, hourStart, hourEnd);
			request.setAttribute("rooms", rooms);
			request.setAttribute("date", date);
			request.setAttribute("hourStart", hourStart);
			request.setAttribute("hourEnd", hourEnd);
		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("error", "Il n'y a pas de salles disponibles ce jour-ci");
			request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
			return;
		}
		request.getRequestDispatcher("/views/reservation/listRooms.jsp").forward(request, response);
	}
	
	/**
	 * Permet d'effectuer une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	public void reserveAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String choiceRoom = (request.getParameter("choiceRoom") == null) ? "0" : request.getParameter("choiceRoom");
		int idRoom = Integer.parseInt(choiceRoom);
		

		ArrayList <Integer> reserve = new ArrayList<Integer>();
		reserve.add(idRoom);
		
		if(!this.isConnected(request)) {
			request.getSession().setAttribute("reserve", reserve);
			response.sendRedirect("login");
			return;
		}
		
		User user = (User) request.getSession().getAttribute("user");
		String date = request.getParameter("date");
		String hourStart = request.getParameter("hourStart");
		String hourEnd = request.getParameter("hourEnd");
		
		try {
			Room room = dispatcher.getRoom(idRoom);
			dispatcher.addReservation(room, user, date, hourStart, hourEnd);
		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("error", "La salle que vous souhaitiez r�server n'a pas �t� trouv�e !");
			request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
			return;
		}
		request.getSession().removeAttribute("reserve");
		response.sendRedirect("user?action=listReservations");
	}
	
	/**
	 * Permet d'annuler une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException  
	 */
	private void cancelAction(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		if(!this.isConnected(request)) {
			response.sendRedirect("login");
			return;
		}
		
		String idReservationParameter = (request.getParameter("idReservation") == null) ? "0" : request.getParameter("idReservation");
		int idReservation = Integer.parseInt(idReservationParameter);;
		
		try {
			Reservation reservation = dispatcher.getReservation(idReservation);
			dispatcher.cancelReservation(reservation);

		} catch (NotFoundException e) {
			e.printStackTrace();
			request.setAttribute("error", "La r�servation que vous souhaitez annuler n'a pas �t� trouv�e !");
			request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
			return;
		}
		
		response.sendRedirect("user?action=listReservations");
		return;
	}
	
	/**
	 * V�rifie si l'user est connect�
	 * 
	 * @return true si il est connect�
	 */
	private boolean isConnected(HttpServletRequest request) {
		return(request.getSession().getAttribute("user") != null);
	}
}
