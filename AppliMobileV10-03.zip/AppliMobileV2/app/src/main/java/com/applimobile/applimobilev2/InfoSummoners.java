package com.applimobile.applimobilev2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import net.rithms.riot.constant.Region;
import net.rithms.riot.dto.Stats.AggregatedStats;
import net.rithms.riot.dto.Stats.ChampionStats;
import net.rithms.riot.dto.Stats.PlayerStatsSummary;
import net.rithms.riot.dto.Stats.RankedStats;
import net.rithms.riot.dto.Summoner.MasteryPage;
import net.rithms.riot.dto.Summoner.MasteryPages;
import net.rithms.riot.dto.Summoner.RunePage;
import net.rithms.riot.dto.Summoner.RunePages;
import net.rithms.riot.dto.Summoner.Summoner;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Set;

/**
 * Permet la gestion de l'activité d'infosummoners
 *
 * Created by Thomas on 27/02/2016.
 */
public class InfoSummoners extends Activity {
	final static RiotApi api = new RiotApi("93f6127b-6ca0-4c0e-9aea-e0832feec88b");

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.infosummoners_layout);

		Log.i("oui", "Info Sumonners lancé");

		Intent intent = getIntent();
		String sn = intent.getStringExtra(MainActivity.EXTRA_SN);

		TextView textViewSN = (TextView) findViewById(R.id.textViewSN);
		textViewSN.setText(sn);

		// RECUPERATION DES VIEWS
		TextView textVUnreal = (TextView) findViewById(R.id.textVUnreal);
		TextView textVTriple = (TextView) findViewById(R.id.textVTriple);
		TextView textVQuadra = (TextView) findViewById(R.id.textVQuadra);
		TextView textVPenta = (TextView) findViewById(R.id.textVPenta);
		TextView textVFirstBlood = (TextView) findViewById(R.id.textVFirstBlood);
		TextView textVMinions = (TextView) findViewById(R.id.textVMinions);
		TextView textVKills = (TextView) findViewById(R.id.textVKills);
		TextView textVAssists = (TextView) findViewById(R.id.textVAssists);
		TextView textVDamageDealt = (TextView) findViewById(R.id.textVDamageDealt);
		TextView textVDamageTaken = (TextView) findViewById(R.id.textVDamageTaken);
		TextView textVHeals = (TextView) findViewById(R.id.textVHeals);
		TextView textVGoldEarned = (TextView) findViewById(R.id.textVGoldEarned);

		ImageView imgV = (ImageView) findViewById(R.id.imageVIcone);
		//FIN RECUPERATION DES VIEWS


		Summoner summoner = getSummonersByName(sn);

		if (summoner == null){
			Toast.makeText(this, "Le summoner n'existe pas", Toast.LENGTH_SHORT).show();
			this.finish();
		}

		long idSummoner = summoner.getId();
		Log.i("oui", "summoner récupéré ; ID : " + String.valueOf(idSummoner));


		try {
			//Récupération des infromations concernant le Summoner
			MasteryPages listMasteries = api.getMasteryPages(Region.EUW, idSummoner);
			RunePages listRunes = api.getRunePages(Region.EUW, idSummoner);
			Set<MasteryPage> setMasteries = listMasteries.getPages();
			Set<RunePage> setRunes = listRunes.getPages();
			List<PlayerStatsSummary> statSumm = api.getPlayerStatsSummary(idSummoner).getPlayerStatSummaries();
			RankedStats rnkStatsSumm = api.getRankedStats(Region.EUW, idSummoner);
			List<ChampionStats> statsRnkByChamp = rnkStatsSumm.getChampions();
			Integer iconeSumm = summoner.getProfileIconId();
			String url = "http://ddragon.leagueoflegends.com/cdn/6.4.1/img/profileicon/" + iconeSumm + ".png";
			Drawable dTemp = loadImg(url, iconeSumm.toString() + ".png");
			imgV.setImageDrawable(dTemp);

			//Initialisations des variables
			int totalUnrealKIlls = 0;
			int totalTripleKills = 0;
			int totalQuadraKills = 0;
			int totalPentaKills = 0;
			int totalFirstBlood = 0;

			int totalMinionsKils = 0;
			int totalChampionsKills = 0;
			int totalAssists = 0;

			int totalHeal = 0;
			int totalDamagesDealt = 0;
			int totalDamagesTaken = 0;

			int totalGoldEarned = 0;


			for (ChampionStats c : statsRnkByChamp) {
				AggregatedStats cT = c.getStats();
				totalUnrealKIlls += cT.getTotalUnrealKills();
				totalTripleKills += cT.getTotalTripleKills();
				totalQuadraKills += cT.getTotalQuadraKills();
				totalPentaKills += cT.getTotalPentaKills();
				totalFirstBlood += cT.getTotalFirstBlood();

				totalMinionsKils += cT.getTotalMinionKills();
				totalChampionsKills += cT.getTotalChampionKills();
				totalAssists += cT.getTotalAssists();

				totalHeal += cT.getTotalHeal();
				totalDamagesDealt += cT.getTotalDamageDealt();
				totalDamagesTaken += cT.getTotalDamageTaken();

				totalGoldEarned += cT.getTotalGoldEarned();
			}


			textVUnreal.setText("UnrealsKills : " + totalUnrealKIlls);
			textVTriple.setText("TripleKills : " + totalTripleKills);
			textVQuadra.setText("QuadraKills : " + totalQuadraKills);
			textVPenta.setText("PentaKills : " + totalPentaKills);
			textVFirstBlood.setText("First Blood : " + totalFirstBlood);
			textVMinions.setText("CS : " + totalMinionsKils);
			textVKills.setText("Kills : " + totalChampionsKills);
			textVAssists.setText("Assists : " + totalAssists);
			textVDamageDealt.setText("Damage Dealt : " + totalDamagesDealt);
			textVDamageTaken.setText("Damage Taken : " + totalDamagesTaken);
			textVHeals.setText("Heal Done : " + totalHeal);
			textVGoldEarned.setText("Gold Earned : " + totalGoldEarned);

		} catch (RiotApiException e) {
			Log.i("RiotApiPb", "Erreur liée a l'API de riot");
		}
	}

	/**
	 * recupère un Summoner par un nom
	 * @param name le nom
	 * @return Le Summoner récupéré
	 */
	public static Summoner getSummonersByName(String name) {
		Summoner summoner = null;

		try {
			api.setRegion(Region.EUW);

			summoner = api.getSummonerByName(Region.EUW, name);

		} catch (RiotApiException e) {
			Log.i("RiotApiPb", "Erreur liée a l'API de riot");
		}
		return summoner;
	}

	/**
	 * Chargement de l'image a partir d'un URL
	 * @param url l'URL
	 * @param name un nomo
	 * @return Un drawable representant l'image
	 */
	public static Drawable loadImg(String url, String name) {
		try {
			InputStream is = (InputStream) new URL(url).getContent();
			Drawable d = Drawable.createFromStream(is, name);
			return d;
		} catch (Exception e) {
			Log.i("oui", "image non recue");
			return null;
		}
	}


	/**
	 * ajoute ou supprime le summoner des favoris
	 *
	 * @param view le boutton
	 */
	public void favori(View view) {
		Log.i("oui", "ouverture de la base");
		SqliteHandler dbHandler = new SqliteHandler(this, null, null, 1);

		String pseudo = ((TextView) findViewById(R.id.textViewSN)).getText().toString();

		SummonerBase summoner = new SummonerBase(pseudo);

		Log.i("oui", String.valueOf(dbHandler.favori(summoner)));
		// s'il n'est pas en favori, alors l'ajouter, le supprimer sinon
		if (dbHandler.favori(summoner)) {
			dbHandler.suppSummoner(summoner);
			Toast.makeText(this, "Supprimé des favoris", Toast.LENGTH_SHORT).show();
		} else {
			dbHandler.addFavori(summoner);
			Toast.makeText(this, "Ajouté aux favoris", Toast.LENGTH_SHORT).show();
		}
		Log.i("oui", "Fin");
	}
}
