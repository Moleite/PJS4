package com.applimobile.applimobilev2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import net.rithms.riot.api.RiotApi;

import java.util.ArrayList;

import static com.applimobile.applimobilev2.InfoChampion.loadImg;

/**
 * Pour afficher Splashs artwork
 *
 * Created by ZHOU Eric on 01/03/2016.
 */
public class SplashChamp extends Activity {

	private RiotApi api = new RiotApi("93f6127b-6ca0-4c0e-9aea-e0832feec88b");
	private ArrayList<Integer> listeImage;
	private String championName;
	private int numImg = 0;
	private String source = "http://ddragon.leagueoflegends.com/cdn/img/champion/splash/";
	private String image;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_layout);

		Intent intent = getIntent();


		ImageView imgSplash = (ImageView) findViewById(R.id.splash_img);

		championName = intent.getStringExtra(InfoChampion.EXTRA_CHAMPION_NAME);
		listeImage = intent.getIntegerArrayListExtra(InfoChampion.EXTRA_TAB_SKINS);

		String source = "http://ddragon.leagueoflegends.com/cdn/img/champion/splash/";
		image = championName + "_" + numImg + ".jpg";
		String url = source + image;

		Drawable splash_draw = loadImg(url, image);

		imgSplash.setImageDrawable(splash_draw);

		Log.i("oui", "image affiché");


	}

	/**
	 * Change l'image
	 * @param view l'immage a changer
	 */
	public void changeImg(View view) {
		numImg++;

		Log.i("oui", String.valueOf(numImg));

		if (numImg >= listeImage.size()) {
			numImg = 0;
		}

		image = championName + "_" + listeImage.get(numImg) + ".jpg";
		String url = source + image;

		ImageView imgSplash = (ImageView) view;

		Drawable splash_draw = loadImg(url, image);

		imgSplash.setImageDrawable(splash_draw);

		Log.i("oui", "image affiché");
	}
}
