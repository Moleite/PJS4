package com.applimobile.applimobilev2;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Activité principale de l'application
 */
public class MainActivity extends AppCompatActivity {

	public static final String EXTRA_SN = "com.projet.applimobile.applimobile.EXTRA_SN";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		Log.i("oui", "lancement OnCreate");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		//noinspection SimplifiableIfStatement
		if (id == R.id.action_settings) {
			return true;
		}

		return super.onOptionsItemSelected(item);
	}

	/**
	 * Affiche la liste des Champions
	 *
	 * @param view une vue
	 */
	public void liste(View view) {
		Intent intent = new Intent(this, ListChampions.class);
		startActivity(intent);
	}

	/**
	 * Changement d'activité vers les informations d'un joueur
	 *
	 * @param view une vue
	 */
	public void info(View view) {
		EditText editTextSN = (EditText) findViewById(R.id.editTextPseudo);
		String sn = editTextSN.getText().toString();

		Log.i("oui", sn);

		if (!sn.isEmpty()) {
			Intent intent = new Intent(this, InfoSummoners.class);
			intent.putExtra(EXTRA_SN, sn);
			Log.i("oui", "lancement de InfoSumonner");
			startActivity(intent);
		} else {
			Toast toast = Toast.makeText(getApplicationContext(), R.string.toast_enter_summoner_name, Toast.LENGTH_SHORT);
			toast.show();
		}
	}

	/**
	 * pour afficher la liste des Sommoners en favori
	 * @param view une vue
	 */
	public void listeFavori(View view) {
		Intent intent = new Intent(this, ListSummoners.class);
		startActivity(intent);
	}
}
