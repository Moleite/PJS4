package com.applimobile.applimobilev2;

/**
 * Une classe Summoner très simplifié pour un enregistrement en base simplifié
 *
 * Created by Utilisateur on 09/03/2016.
 */
public class SummonerBase {

	private String pseudo;

	public SummonerBase(){}

	public SummonerBase(String pseudo){
		this.pseudo = pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}

	public String getPseudo() {
		return pseudo;
	}

	public String toString(){
		return pseudo;
	}
}
