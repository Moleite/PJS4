package com.applimobile.applimobilev2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Utilisé pour la gestion de la base de données en SQLite
 *
 * Created by Utilisateur on 09/03/2016.
 */
public class SqliteHandler extends SQLiteOpenHelper {

	private static final int VERSION = 1;
	private static final String BASE_NOM = "appMobFavori.db";

	private static final String TABLE_SUMMONERS = "sumonners";
	public static final String COL_PSEUDO = "productName";

	public SqliteHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
		super(context, BASE_NOM, factory, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// CREATE TABLE summoners (id INTEGER, pseudo TEXT)
		String CREATE_PRODUCTS_TABLE = "CREATE TABLE " +
				TABLE_SUMMONERS + "(" + COL_PSEUDO + " TEXT)";
		db.execSQL(CREATE_PRODUCTS_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_SUMMONERS);
		onCreate(db);
	}

	/**
	 * Met le Summoner en favori
	 *
	 * @param summoner le Summoner a ajouter en favori
	 */
	public void addFavori(SummonerBase summoner ) {

		ContentValues values = new ContentValues();
		values.put(COL_PSEUDO, summoner.getPseudo());

		SQLiteDatabase db = this.getWritableDatabase();

		db.insert(TABLE_SUMMONERS, null, values);
		db.close();
	}


	/**
	 * Récupere la liste des summoners dans la base (en favori)
	 *
	 * @return La liste des summoners
	 */
	public List<SummonerBase> getAllSummoners() {
		String query = "SELECT * FROM " + TABLE_SUMMONERS;

		Log.i("oui", "Recuperation de la base ");
		SQLiteDatabase db = this.getWritableDatabase();

		Cursor cursor = db.rawQuery(query, null);

		List<SummonerBase> listeSummoners = new ArrayList<>();

		while (cursor.moveToNext()) {
			listeSummoners.add(new SummonerBase(cursor.getString(0)));
		}

		cursor.close();

		return listeSummoners;
	}

	/**
	 * Pour supprimer un Summoner de la liste des favori
	 *
	 * @param summoner le pseudo du summoner a supprimer
	 * @return true si le summoner est bien supprimé false sinon
	 */
	public void suppSummoner(SummonerBase summoner) {


		// SELECT * FROM summoner WHERE pseudo = "summoner"
		String query = "SELECT * FROM " + TABLE_SUMMONERS + " WHERE " + COL_PSEUDO + " =  \"" + summoner.getPseudo() + "\"";

		SQLiteDatabase db = this.getWritableDatabase();

		Cursor cursor = db.rawQuery(query, null);

		SummonerBase summonerASupp = new SummonerBase();

		if (cursor.moveToFirst()) {
			summonerASupp.setPseudo((cursor.getString(0)));
			db.delete(TABLE_SUMMONERS, COL_PSEUDO + " = ?", new String[] {String.valueOf(summonerASupp.getPseudo())});
			cursor.close();
		}
		db.close();
	}

	/**
	 * Determine si un summoner est dans la liste des favoris ou non
	 *
	 * @param summoner
	 * @return
	 */
	public boolean favori(SummonerBase summoner) {
		boolean result = false;
		String query = "SELECT * FROM " + TABLE_SUMMONERS + " WHERE " + COL_PSEUDO + " =  \"" + summoner.getPseudo() + "\"";

		SQLiteDatabase db = this.getWritableDatabase();

		Cursor cursor = db.rawQuery(query, null);

		// s'il trouve un summoner alors il est en favori
		if (cursor.moveToFirst()) {
			result = true;
		}
		db.close();
		return result;
	}
}
