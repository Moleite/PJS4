package com.applimobile.applimobilev2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * La class pour la gestion de l'activité de la liste des sommoners
 *
 * Created by ZHOU Eric on 09/03/2016.
 */
public class ListSummoners extends Activity {
	/**
	 * Un petit souci pour le this d'un intent
	 */
	ListSummoners listesummonerclass = this;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listsummoners_layout);

		ListView listeSummoners = (ListView) findViewById(R.id.listeSummoners);

		SqliteHandler dbHandler = new SqliteHandler(this, null, null, 1);

		Log.i("oui", "Récupération des Sommoners");
		List<SummonerBase> listeSummonersBase = dbHandler.getAllSummoners();

		final List<String> listePseudo = new ArrayList<>();

		// transformation en une liste de pseudo
		for (SummonerBase sb : listeSummonersBase){
			listePseudo.add(sb.getPseudo());
		}

		ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listePseudo);
		listeSummoners.setAdapter(arrayAdapter);

		listeSummoners.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent intent = new Intent(listesummonerclass, InfoSummoners.class);

				intent.putExtra(MainActivity.EXTRA_SN, listePseudo.get(position));

				startActivity(intent);
			}
		});

	}
}
