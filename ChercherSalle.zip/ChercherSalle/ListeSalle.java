package com.example.hadbi.pjs4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.hadbi.pjs4.Erreur.ErreurConnexion;
import com.example.hadbi.pjs4.Erreur.ErreurReservation;
import com.example.hadbi.pjs4.HttpRequete.HttpChercherSalle;
import com.example.hadbi.pjs4.HttpRequete.HttpReservation;

import org.apache.http.HttpResponse;

import java.util.ArrayList;

public class ListeSalle extends Activity {

    private String Salle;
    private String Date;
    private String Performance;
    private String RAM;
    private String HeureD;
    private String HeureF;
    private ListView ListeSalle;
    private Button retourReserv;
    private HttpReservation conn = new HttpReservation();
    private HttpChercherSalle connSalle = new HttpChercherSalle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_salle);

        HeureD = this.getIntent().getStringExtra("HeureDebut");
        HeureF = this.getIntent().getStringExtra("HeureFin");
        Date = this.getIntent().getStringExtra("Date");

        /*if(this.getIntent().getStringExtra("Performance") != null) {
           Performance = this.getIntent().getStringExtra("Performance");
        }
        if(this.getIntent().getStringExtra("RAM") != null) {
            RAM = this.getIntent().getStringExtra("RAM");
        }*/

        ListeSalle = (ListView) findViewById(R.id.ListSalle);

        ArrayList<String> LesSalles = connSalle.ChercherSalle(HeureD, HeureF, Date);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.activity_list_item, LesSalles);
        ListeSalle.setAdapter(adapter);

        /* Fonction pour réserver qui lance la requete pour réserver quand on clique sur une salle (pas sûr qu'elle marche)*/
        ListeSalle.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String s = (String) ListeSalle.getItemAtPosition(position);
                try {
                    conn.Reservation(s);
                } catch (ErreurConnexion erreurConnexion) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Problème de reservation", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                }
            }
        });

        retourReserv = (Button) findViewById(R.id.ButtonChang);

        retourReserv.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
             Intent Change = new Intent(ListeSalle.this, ChercherSalle.class);
               startActivity(Change);
              }
            }

       );
    }


}
