package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import com.google.gson.Gson;

import exception.NotFoundException;
import model.DuoList;
import model.Reservation;
import model.Room;
import model.Dispatcher;
import model.User;


public class ReservationController extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private Dispatcher dispatcher = Dispatcher.getInstance();

	/**
	 * Renvoie � l'action correspondante aux param�tres
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String on = "";
		if (request.getParameterMap().containsKey("on")) {
			on = request.getParameter("on");
		}
		
        String action = request.getParameter("action");
		action = (action == null) ? "index" : action;
		
		if(action.equals("listRooms"))
			this.listRoomsAction(request, response, on);
		else if(action.equals("reserve"))
			this.reserveAction(request, response, on);
		else if(action.equals("cancel"))
			this.cancelAction(request, response, on);
		else
			request.getRequestDispatcher("/views/error/404.jsp").forward(request, response);

	}
	
	/**
	 * Liste les rooms en fonction des param�tres du formulaire
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void listRoomsAction(HttpServletRequest request, HttpServletResponse response, String on) throws IOException, ServletException {
		if(on.equals("app")) {

			String dateReservation = "01/03/2016";
			String hourStart = "15:15:00";
			String hourEnd = "15:16:00";
			
			try {
				DuoList rooms  = (DuoList) dispatcher.getRooms(dateReservation, hourStart, hourEnd);
				String jsonRooms = new Gson().toJson(rooms); 
				response.setHeader("jsonRooms", jsonRooms);
				
				response.setHeader("dateReservation", dateReservation);
				response.setHeader("hourStart", hourStart);
				response.setHeader("hourEnd", hourEnd);
				
				response.setHeader("statut", "ok");
			} catch (NotFoundException e) {
				e.printStackTrace();
				response.setHeader("statut", "ko");
			}
		} else {
			String dateReservation = request.getParameter("dateReservation");
			String hourStart = request.getParameter("hourStart");
			String hourEnd = request.getParameter("hourEnd");
			
			try {
				DuoList rooms  = (DuoList) dispatcher.getRooms(Reservation.convertDate(dateReservation), hourStart, hourEnd);
				request.setAttribute("rooms", rooms);
				request.getSession().setAttribute("dateReservation", dateReservation);
				request.getSession().setAttribute("hourStart", hourStart);
				request.getSession().setAttribute("hourEnd", hourEnd);
			} catch (NotFoundException e) {
				e.printStackTrace();
				request.setAttribute("error", "Il n'y a pas de salles disponibles ce jour-ci");
				request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
				return;
			}
			request.getRequestDispatcher("/views/reservation/listRooms.jsp").forward(request, response);
		}
	}
	
	/**
	 * Permet d'effectuer une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException 
	 */
	public void reserveAction(HttpServletRequest request, HttpServletResponse response, String on) throws IOException, ServletException {
		if(on.equals("app")) {			
			//recupere l'object json et le deserialize
			String userJson = request.getHeader("userJson");
			User user = new Gson().fromJson(userJson, User.class);
			
			String idRoom = request.getHeader("idRoom");
			String dateReservation = request.getHeader("dateReservation");
			String hourStart = request.getHeader("hourStart");
			String hourEnd = request.getHeader("hourEnd");
			
			try {
				Room room = dispatcher.getRoom(Integer.parseInt(idRoom));
				dispatcher.addReservation(room, user, dateReservation, hourStart, hourEnd);
				
				response.setHeader("statut", "ok");	
			} catch (NotFoundException e) {
				e.printStackTrace();
				response.setHeader("statut", "ko");	
			}

		}else {
			String choiceRoom = (request.getParameter("choiceRoom") == null) ? "0" : request.getParameter("choiceRoom");
			int idRoom = Integer.parseInt(choiceRoom);
			
	
			ArrayList <Integer> reserve = new ArrayList<Integer>();
			reserve.add(idRoom);
			
			if(!this.isConnected(request)) {
				request.getSession().setAttribute("reserve", reserve);
				response.sendRedirect("login");
				return;
			}
			
			User user = (User) request.getSession().getAttribute("user");
			String dateReservation = (String) request.getSession().getAttribute("dateReservation");
			String hourStart = (String) request.getSession().getAttribute("hourStart");
			String hourEnd = (String) request.getSession().getAttribute("hourEnd");
			
			try {
				Room room = dispatcher.getRoom(idRoom);
				dispatcher.addReservation(room, user, dateReservation, hourStart, hourEnd);
			} catch (NotFoundException e) {
				e.printStackTrace();
				request.setAttribute("error", "La salle que vous souhaitiez r�server n'a pas �t� trouv�e !");
				request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
				return;
			}
			request.getSession().removeAttribute("reserve");
			request.getSession().removeAttribute("dateReservation");
			request.getSession().removeAttribute("hourStart");
			request.getSession().removeAttribute("hourEnd");
			response.sendRedirect("user?action=listReservations");
		}
	}
	
	/**
	 * Permet d'annuler une r�servation
	 * 
	 * @throws IOException 
	 * @throws ServletException  
	 */
	private void cancelAction(HttpServletRequest request, HttpServletResponse response, String on) throws IOException, ServletException{
		if(on.equals("app")) {
			int idReservation = Integer.parseInt(request.getHeader("idReservation"));
			
			try {
				Reservation reservation = dispatcher.getReservation(idReservation);
				dispatcher.cancelReservation(reservation);
				
				response.setHeader("statut", "ok");
			} catch (NotFoundException e) {
				e.printStackTrace();
				response.setHeader("statut", "ko");
			}
		}else {
			if(!this.isConnected(request)) {
				response.sendRedirect("login");
				return;
			}
			
			String idReservationParameter = (request.getParameter("idReservation") == null) ? "0" : request.getParameter("idReservation");
			int idReservation = Integer.parseInt(idReservationParameter);;
			
			try {
				Reservation reservation = dispatcher.getReservation(idReservation);
				dispatcher.cancelReservation(reservation);
	
			} catch (NotFoundException e) {
				e.printStackTrace();
				request.setAttribute("error", "La r�servation que vous souhaitez annuler n'a pas �t� trouv�e !");
				request.getRequestDispatcher("/views/error/500.jsp").forward(request, response);
				return;
			}
			
			response.sendRedirect("user?action=listReservations");
			return;
		}
	}
	
	/**
	 * V�rifie si l'user est connect�
	 * 
	 * @return true si il est connect�
	 */
	private boolean isConnected(HttpServletRequest request) {
		return(request.getSession().getAttribute("user") != null);
	}
	
}
