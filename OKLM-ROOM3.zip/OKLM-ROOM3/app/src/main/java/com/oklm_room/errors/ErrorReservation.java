package com.oklm_room.errors;

/**
 * Created by tatlot1 on 25/03/2016.
 */
public class ErrorReservation extends Exception {
    public ErrorReservation() {
    }

    public ErrorReservation(String detailMessage) {
        super(detailMessage);
    }

    public ErrorReservation(Throwable throwable) {
        super(throwable);
    }

    public ErrorReservation(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }
}
