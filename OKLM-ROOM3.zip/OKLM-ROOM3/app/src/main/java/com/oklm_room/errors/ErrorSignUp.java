package com.oklm_room.errors;

/**
 * Created by tatlot1 on 25/03/2016.
 */
public class ErrorSignUp extends Exception {
    public ErrorSignUp() {
    }

    public ErrorSignUp(String detailMessage) {
        super(detailMessage);
    }

    public ErrorSignUp(Throwable throwable) {
        super(throwable);
    }

    public ErrorSignUp(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }
}
