package com.oklm_room.errors;

/**
 * Created by tatlot1 on 25/03/2016.
 */
public class ErrorSignIn extends Exception {
    public ErrorSignIn() {
    }

    public ErrorSignIn(String detailMessage) {
        super(detailMessage);
    }

    public ErrorSignIn(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public ErrorSignIn(Throwable throwable) {
        super(throwable);
    }
}
