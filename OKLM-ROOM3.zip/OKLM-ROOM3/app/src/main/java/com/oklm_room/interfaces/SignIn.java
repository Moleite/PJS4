package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.oklm_room.MainActivity;
import com.oklm_room.R;
import com.oklm_room.errors.ErrorSignIn;
import com.oklm_room.http_requests.HttpSignIn;

public class SignIn extends Activity {

    private Button retour;
    private Button connexion;
    private EditText pseudo;
    private EditText mdp;
    private HttpSignIn conn = new HttpSignIn();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        retour = (Button) findViewById(R.id.Retour);
        connexion = (Button) findViewById(R.id.Connexion);
        pseudo = (EditText) findViewById(R.id.Pseudo);
        mdp = (EditText) findViewById(R.id.Mdp);



        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retour = new Intent(SignIn.this, MainActivity.class);
                startActivity(retour);
            }
        });


        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View V) {
                try {
                    conn.connexion(pseudo.getText().toString(), mdp.getText().toString());
                    Intent connexion = new Intent(SignIn.this, Reservation.class);
                    connexion.putExtra("Pseudo", pseudo.getText());
                    startActivity(connexion);
                } catch (ErrorSignIn e) {

                    Toast toast = Toast.makeText(SignIn.this, "Mauvais identifiants de connexion, veuillez réssayer", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                    pseudo.setText("");
                    mdp.setText("");
                }
            }
        });
    }
}
