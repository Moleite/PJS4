package com.oklm_room;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.oklm_room.interfaces.SignIn;
import com.oklm_room.interfaces.SignUp;

public class MainActivity extends Activity {

    private Button inscription;
    private Button connexion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        inscription = (Button) findViewById(R.id.Inscription);
        connexion = (Button) findViewById(R.id.Connexion);

        inscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inscription = new Intent(MainActivity.this, SignUp.class);
                startActivity(inscription);
            }
        });

        connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent connexion = new Intent(MainActivity.this, SignIn.class);
                startActivity(connexion);
            }
        });

    }
}
