package com.oklm_room.interfaces;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.oklm_room.R;

public class Reservation extends Activity {

    private TextView pseudo;
    private String Pseudorecup;
    private EditText DateR;
    private Button Confirmation;
    private EditText Salle;
    private EditText Performance;
    private EditText RAM;
    private CheckBox PerformanceC;
    private CheckBox RAMC;
    private int verif;
    /* public bdd personne;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);
        Pseudorecup = this.getIntent().getStringExtra("Pseudo");

        pseudo = (TextView) findViewById(R.id.PseudoTxt);
        pseudo.setText(Pseudorecup);
        DateR = (EditText) findViewById(R.id.DateReserv);
        Confirmation = (Button) findViewById(R.id.buttonConf);
        Salle = (EditText) findViewById(R.id.SalleTxt);
        Performance = (EditText) findViewById(R.id.PerfomanceTxt);
        RAM = (EditText) findViewById(R.id.RAMTxt);


        PerformanceC = (CheckBox) findViewById(R.id.PerformanceCheck);
        if(PerformanceC.isChecked()) {
            Performance.setVisibility(View.VISIBLE);
        }

        RAMC = (CheckBox) findViewById(R.id.RAMCheck);
        if(RAMC.isChecked()) {
            RAM.setVisibility(View.VISIBLE);
        }




        Confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* verif = personne.reservation(Salle.getText(), Confirmation.getText(),...)*/
                if (verif == 1) {
                    Intent reservation = new Intent(Reservation.this, RoomsList.class);
                    startActivity(reservation);
                }
                else {
                    Toast toast = Toast.makeText(Reservation.this, "Problème de réservation", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 0);
                }
            }
        });

    }
}