package com.oklm_room.http_requests;



import com.oklm_room.errors.ErrorSignIn;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by tatlot1 on 25/03/2016.
 */
public class HttpSignIn {

    ArrayList<NameValuePair> ListeParametre = new ArrayList<NameValuePair>();
    HttpPost httppost = new HttpPost(/*ULR DU SITE*/);

    public void connexion(final String pseudo, final String mdp) throws ErrorSignIn {

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    ListeParametre.add(new BasicNameValuePair("Pseudo", pseudo));
                    ListeParametre.add(new BasicNameValuePair("Mdp", mdp));

                    httppost.setEntity(new UrlEncodedFormEntity(ListeParametre));
                    HttpClient httpClient = new DefaultHttpClient();
                    httpClient.execute(httppost);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            };
        }).start();
    }

}