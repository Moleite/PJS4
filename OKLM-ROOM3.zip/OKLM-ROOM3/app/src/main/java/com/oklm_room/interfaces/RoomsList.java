package com.oklm_room.interfaces;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import com.oklm_room.R;

public class RoomsList extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms_list);

        ListView mListView = (ListView) findViewById(R.id.listView);
    }
}
