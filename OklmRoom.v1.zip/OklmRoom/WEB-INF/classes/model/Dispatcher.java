package model;

import java.util.List;

import exception.NotFoundException;
import exception.UserAlreadyExistException;
import exception.UserNotFoundException;
import persistence.*;


/**
 * Classe g�n�rale de l'application en charge de d�l�guer les diff�rentes actions possibles sur le mod�le
 */
public class Dispatcher {
	
	private static Dispatcher instance = new Dispatcher();
	private static ReservationDAO reservationDAO = ReservationDAO.getInstance();
	private static RoomDAO roomDAO = RoomDAO.getInstance();
	private static UserDAO userDAO = UserDAO.getInstance();
	
	
	/**
	 * Ajouter une r�servation
	 * 
	 * @param room La salle r�serv�e
	 * @param user Le compte qui reserve
	 * @param hourEnd L'heure de fin de la r�servation
	 */
	public void addReservation(Room room, User user, String date, String hourStart, String hourEnd) {
		reservationDAO.addReservation(room, user, date, hourStart, hourEnd);
	}
	
	/**
	 * R�cup�rer une r�servation � partir de son num�ro unique
	 * 
	 * @param nbReservation Num�ro de la r�servation
	 * @return la r�servation correspondante au num�ro
	 * @throws NotFoundException si la r�servation ou ses diff�rentes composantes (salle, utilisateur) sont introuvables
	 */
	public Reservation getReservation(int nbReservation) throws NotFoundException {
		return reservationDAO.findReservation(nbReservation);
	}
	
	/**
	 * R�cup�rer l'ensemble des r�servation d'un utilisateur
	 * 
	 * @param user l'utilisateur dont on recherche les r�servation
	 * @return une liste de r�servation
	 */
	public List<Reservation> getReservations(User user) {
		return reservationDAO.findReservations(user);
	}

	/**
	 * Supprimer une r�servation
	 * 
	 * @param reservation la r�servation � supprimer
	 */
	public void cancelReservation(Reservation reservation) {
		reservationDAO.cancelReservation(reservation);
	}

	/**
	 * Ajouter une Room
	 * 
	 * @param String nbRoom Nom de la Room
	 * @param int nbSeat Nombre de places dans la Room
	 * @param String screen Taille des ecrans dans la Room
	 * @param String processor Puissance des ordinateurs dans la Room
	 * @param String ram des ordinateurs dans la Room
	 * @param int floorId Floor dans lequel la Room se situe
	 */
	public Room addRoom(String nbRoom, int nbSeat, String screen, String processor, String ram, int floorId) {
		Room room = new Room(nbRoom, nbSeat, screen, processor, ram, floorId);
		roomDAO.addRoom(room);
		return room;
	}
	
	/**
	 * R�cup�rer une salle � partir de son num�ro 
	 * 
	 * @param nbRoom le num�ro du la salle
	 * @return la salle correspondante
	 * @throws NotFoundException si la salle correspondant est introuvable
	 */
	public Room getRoom(int idRoom) throws NotFoundException {
		return roomDAO.findRoom(idRoom);
	}
	
	/**
	 * R�cup�rer l'ensemble des salles suivant certains crit�res
	 * 
	 * 
	 * @param date Date de la r�servation
	 * @return une liste de salle
	 * @throws NotFoundException 
	 */
	public List<List<Room>> getRooms(String date, String hourStart, String hourEnd) throws NotFoundException{
		return roomDAO.findRooms(date, hourStart, hourEnd);
	}
	
	/**
	 * Ajouter un User
	 * 
	 * @param lastname Lastname choisi pour l'user
	 * @param firstname Firstname choisi pour l'user
	 * @param pseudo Pseudo choisi pour l'user
	 * @param password Password choisi pour l'user
	 * @param right Right de l'user (utilisateur ou super_utilisateur ou admin)
	 * @return l'user ainsi ajout�
	 * @throws UserAlreadyExistException si un user correspondant au pseudo existe d�j�
	 */
	public User addUser(String lastname, String firstname, String pseudo, String password) 
			throws UserAlreadyExistException {
		User user = new User(lastname, firstname, pseudo, password);
		userDAO.addUser(user);
		return user;
	}
	
	/**
	 * R�cup�rer un user � partir de son pseudo et de son password
	 * 
	 * @param pseudo Login suppos� du compte
	 * @param password Mot de passe suppos� du compte
	 * @return le compte correspondant aux param�tres
	 * @throws UserNotFoundException si aucun utilisateur ne poss�de cette combinaison
	 */
	public User getUser(String pseudo, String password)
		 throws  UserNotFoundException{
		User user = userDAO.findUser(pseudo, password);
		return user;
	}
	
	/**
	 * R�cup�rer l'instance unique du Dispatcher (Singleton)
	 * 
	 * @return l'instance
	 */
	public static Dispatcher getInstance() {
		return instance;
	}

}