package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exception.UserNotFoundException;
import model.Dispatcher;
import model.User;

public class LoginController extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private Dispatcher dispatcher = Dispatcher.getInstance();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		request.getRequestDispatcher("/views/login/signIn.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		if (request.getParameterMap().containsKey("on")) {
			
			if (request.getParameter("on").equals("app")) {
//				
//				String pseudo = "?";//Object JSON
//				String password = "?";//Object JSON
//				
//				User user;
//				try {
//					user = dispatcher.getUser(pseudo, password);
//					//renvoyer user en JSON
					response.setHeader("statut", "ok");
//				} catch (UserNotFoundException e) {
//					e.printStackTrace();
//					response.setHeader("statut", "ko");
//				}
			}
			
		} else {
			String pseudo = request.getParameter("pseudo");
			String password = request.getParameter("password");
			HttpSession session = request.getSession();
			
			User user;
			try {
				user = dispatcher.getUser(pseudo, password);
				session.setAttribute("user", user);
				if(session.getAttribute("reserve") != null) {
					response.sendRedirect("reservation?action=reserve&choice=" + session.getAttribute("reserve"));
					return;
				}
				response.sendRedirect("index");
			} catch (UserNotFoundException e) {
				e.printStackTrace();
				response.sendRedirect("login?error");
			}
		}

	}
}
